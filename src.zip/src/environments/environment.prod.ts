
export const environment = {
  production: true,
  //firebaseAPIKey: 'AIzaSyD0WFxK9J615nkxVI795qLWLmNe5VidGYA'
  firebase: {
    apiKey: "AIzaSyD0WFxK9J615nkxVI795qLWLmNe5VidGYA",
    authDomain: "driveshare-c4036.firebaseapp.com",
    databaseURL: "https://driveshare-c4036-default-rtdb.firebaseio.com",
    projectId: "driveshare-c4036",
    storageBucket: "driveshare-c4036.appspot.com",
    messagingSenderId: "668647538417",
    appId: "1:668647538417:web:22210b1a6061e22047b350",
    emulatorHost: "localhost",
    emulatorPort: 8100
  }
};

