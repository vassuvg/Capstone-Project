// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  //firebaseAPIKey: 'AIzaSyD0WFxK9J615nkxVI795qLWLmNe5VidGYA'
  firebase: {
    apiKey: "AIzaSyD0WFxK9J615nkxVI795qLWLmNe5VidGYA",
    authDomain: "driveshare-c4036.firebaseapp.com",
    databaseURL: "https://driveshare-c4036-default-rtdb.firebaseio.com",
    projectId: "driveshare-c4036",
    storageBucket: "driveshare-c4036.appspot.com",
    messagingSenderId: "668647538417",
    appId: "1:668647538417:web:22210b1a6061e22047b350",
    emulatorHost: "localhost",
    emulatorPort: 8100 
  }
};

//AIzaSyAv7fGwFqmb3lVEawsjazB3VZdVZCi0Vdo



/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
