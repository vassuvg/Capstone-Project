import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NavController } from '@ionic/angular';
import { AuthService } from '../auth/auth.service';
import { forkJoin, map, switchMap, take } from 'rxjs';

@Component({
  selector: 'app-booking-passenger',
  templateUrl: './booking-passenger.component.html',
  styleUrls: ['./booking-passenger.component.scss'],
})
export class BookingPassengerComponent  implements OnInit {
  bookingId: string;
  bookingData: any[] = [];

  constructor(
    private route: ActivatedRoute,
    private http: HttpClient,
    private navCtrl: NavController,
    private authService: AuthService // Inject AuthService
  ) {}

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.bookingId = params['bookingId'];
      this.fetchBookingData();
    });
  }

  fetchBookingData() {
    this.authService.userId.pipe(
      take(1),
      switchMap(userId => 
        this.http.get<{ [key: string]: any }>('https://driveshare-c4036-default-rtdb.firebaseio.com/acceptedrides.json')
          .pipe(
            map(response => {
              const bookings = response ? Object.values(response) : [];
              return bookings.filter((booking: any) => 
                booking.rideId === this.bookingId && booking.passengerId === userId
              );
            }),
            switchMap(bookings => {
              const passengerDetailRequests = bookings.map((booking: any) => 
                this.http.get(`https://driveshare-c4036-default-rtdb.firebaseio.com/passengerDetails/${booking.passengerId}/${booking.PassengerRideID}.json`)
              );

              const driverDetailRequests = bookings.map((booking: any) => 
                this.http.get(`https://driveshare-c4036-default-rtdb.firebaseio.com/driverRideData/${booking.driverId}/${booking.driverRideId}.json`)
              );

              const profileRequests = bookings.map((booking: any) => 
              this.http.get(`https://driveshare-c4036-default-rtdb.firebaseio.com/profiles/${booking.driverId}.json`)
            );
              return forkJoin([...passengerDetailRequests, ...driverDetailRequests, ...profileRequests])
                .pipe(
                  map(responses => {
                    const bookingCount = bookings.length;
                    
                    return bookings.map((booking, index) => ({
                      ...booking,
                      passengerDetails: responses[index],
                      driverDetails: responses[index + bookings.length],
                      profile: Object.values(responses[index + 2 * bookingCount])[0]
                    }));
                  })
                );
            })
          )
      )
    ).subscribe(
      mergedData => {
        this.bookingData = mergedData;
        console.log('Booking data:', this.bookingData);
      },
      error => {
        console.error('Error fetching booking data:', error);
      }
    );
  }
}
