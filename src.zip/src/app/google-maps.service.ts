import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GoogleMapsService {
  private apiUrl = '/maps/api/place/autocomplete/json'; // Proxy URL

  constructor(private http: HttpClient) {}

  getLocation(address: string): Observable<any> {
    //const API_KEY = 'AIzaSyB7UzfhhFrmDJ7kaIrfOseRbZkYzJXh8A0';
    const API_KEY = 'AIzaSyDbtYehjN5DdInZCEsZeQoYr31xXBYmxPw';
    const input = encodeURIComponent(address);
    const url = `${this.apiUrl}?input=${input}&types=geocode&key=${API_KEY}`;
    
    return this.http.get(url);
  }
}

