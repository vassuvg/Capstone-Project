import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { RouterModule } from '@angular/router';
import { ViewdriverRideinfoComponent } from './viewdriver-rideinfo.component';
import { MatchedPassengerDetailComponent } from './matched-passenger-detail/matched-passenger-detail.component';
import { DriverRidesRequestComponent } from './driver-rides-request/driver-rides-request.component';




@NgModule({
  declarations: [ViewdriverRideinfoComponent, MatchedPassengerDetailComponent, DriverRidesRequestComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    IonicModule,
    RouterModule.forChild([
      {
        path: '',
        component: ViewdriverRideinfoComponent
      }
    ])
  ],

  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class ViewDriverRideInfoModule {}
