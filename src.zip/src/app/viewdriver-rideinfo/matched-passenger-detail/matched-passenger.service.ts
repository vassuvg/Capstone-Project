import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { DriverRideData } from 'src/app/driver-ridedata/driver-ridedata.model';
import { PassengerDetail } from 'src/app/passenger/passenger-detail/passenger-detail.model';

@Injectable({
  providedIn: 'root',
})
export class MatchedPassengerService {

    //rideData : any[] = []


   
constructor(private http: HttpClient){
 this.initializeRideData();
}
initializeRideData() {
      
}


getPassengerRideDetails(userId: string, rideId: string) {
  return this.http.get<PassengerDetail>(`https://driveshare-c4036-default-rtdb.firebaseio.com/passengerDetails/${userId}/${rideId}.json`);
}



}