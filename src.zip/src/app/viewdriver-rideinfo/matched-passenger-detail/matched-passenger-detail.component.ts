import { DOCUMENT } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { Subscription, filter, switchMap, take } from 'rxjs';
import { AuthService } from 'src/app/auth/auth.service';
import { DriverInfoService } from 'src/app/driver-rideinfo/driver-rideinfo.service';
import { PassengerDetailService } from 'src/app/passenger/passenger-detail.service';
import { RideService } from 'src/app/passenger/passenger-rides-request/ride.service';
import { ProfileService } from 'src/app/profile/profile.service';
import { MatchedPassengerService } from './matched-passenger.service';
import { PassengerDetail } from 'src/app/passenger/passenger-detail/passenger-detail.model';

@Component({
  selector: 'app-matched-passenger-detail',
  templateUrl: './matched-passenger-detail.component.html',
  styleUrls: ['./matched-passenger-detail.component.scss'],
})
export class MatchedPassengerDetailComponent implements OnInit, OnDestroy {
  passenger: any;
  passengerDetail: any = {};
  userId: string;
  AllRideData: any;
  private MyPassengerData: any;
  xyz: string;
  private routerSubscription: Subscription;
  driverData : any;
  abc: string;

  constructor(
    private router: Router,
    private passengerService: PassengerDetailService,
    private authService: AuthService,
    private http: HttpClient,
    private rideinfoService : DriverInfoService,
    private profileService: ProfileService,
    private alertController: AlertController,
    @Inject(DOCUMENT) private document: Document,
    private rideService : RideService ,
    private matchedPassengerService: MatchedPassengerService
  ) {}

  ngOnInit() {
    this.routerSubscription = this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe(() => {
        const navigation = this.router.getCurrentNavigation();
        if (navigation && navigation.extras.state) {
          this.passenger = navigation.extras.state['passenger'];
          console.log(this.passenger);
          this.xyz = this.passenger.passengerUserId;
          this.abc = this.passenger.passengerRideId;
          console.log(this.xyz);
          console.log(this.abc);

          this.GetFilteredAccount();
        }
      });

    // Initial load
    const navigation = this.router.getCurrentNavigation();
    if (navigation && navigation.extras.state) {
      this.passenger = navigation.extras.state['passenger'];
      console.log(this.passenger);
      this.xyz = this.passenger.passengerUserId;
      this.abc = this.passenger.passengerRideId;
      console.log(this.xyz);
      console.log(this.abc);
      this.GetFilteredAccount();
    }

    this.authService.userId.pipe(
      switchMap(userId => this.rideinfoService.getDriverData(userId))
    ).subscribe(data => {
      this.driverData = data;
      this.userId = data.userId; // assuming userId is a property of passengerData
    });
  }

  async GetFilteredAccount() {
    this.matchedPassengerService.getPassengerRideDetails(this.xyz, this.abc).subscribe(
      (data: PassengerDetail) => {
        if (data) {
          this.passengerDetail = data;
          console.log('Passenger Ride Data:', this.passengerDetail);
        } else {
          console.error('No matching passenger ride data found');
        }
      },
      error => {
        console.error('Error fetching passenger ride data:', error);
      }
    );
  }


  checkExistingBooking(driverId: string, passengerId: string): Promise<boolean> {
    return new Promise((resolve, reject) => {
      this.http.get<any>('https://driveshare-c4036-default-rtdb.firebaseio.com/acceptedrides.json')
        .subscribe(rides => {
          if (rides) {
            console.log('Rides data:', rides);
            
            let existingRide = null;
            for (const tableId in rides) {
              if (rides.hasOwnProperty(tableId)) {
                const ride = rides[tableId];
                console.log('ridesssss',ride)
                if (ride.driverId === driverId && 
                    ride.passengerId === passengerId 
                  ) {
                  existingRide = ride;
                  break;
                }
              }
            }
            
            console.log('Existing Ride:', existingRide);
            resolve(!!existingRide); // Resolve with true if an existing ride is found, otherwise false
          } else {
            resolve(false); // Resolve with false if no rides are found
          }
        }, error => {
          reject(error); // Reject the promise in case of an error
        });
    });
  }
  

  sendRideRequest() {
    this.authService.userId.pipe(take(1)).subscribe(userId => {
      // Retrieve fullName from profile service
      this.profileService.getPassengerData(userId).pipe(take(1)).subscribe(data => {
        if (data) {
          // Extract tableId assuming there's only one
          const tableId = Object.keys(data)[0];
          const fullName = data[tableId]?.fullName;
  
          if (fullName) {
            // Use driver state from RideinfoService
            this.rideinfoService.getDriverState().pipe(take(1)).subscribe(driverState => {
              console.log('Driver State:', driverState); // Log driver state to verify
  
              if (driverState) {
                // Check if the ride is already booked
                this.checkExistingBooking(this.passenger.passengerUserId, userId)
                  .then(isBooked => {
                    if (isBooked) {
                      // Show an alert indicating the ride is already booked
                      this.alertController.create({
                        header: 'Already Booked',
                        message: `You have already booked a ride with ${this.passenger.name} on ${driverState.departureDate}.`,
                        buttons: ['OK']
                      }).then(alert => alert.present());
                    } else {
                      // Proceed with booking
                      const rideRequest = {
                        DriverRideID: driverState.DriverRideID,
                        passengerRideId: this.passenger.passengerRideId,
                        passengerId: this.passenger.passengerUserId,
                        driverName: fullName,
                        origin: driverState.pickupLocation,
                        destination: driverState.dropoffLocation,
                        departureDate: driverState.departureDate,
                        departureTime: driverState.departureTime,
                        seats: driverState.seats,
                        luggage: driverState.luggage,
                        additionalDetails: driverState.additionalDetails,
                        driverId: userId,
                      };
  
                      console.log('Ride Request:', rideRequest); // Log ride request to verify
                      this.rideService.sendRideRequests(rideRequest).subscribe(response => {
                        console.log('Ride request sent:', response);
                      });
                    }
                  })
                  .catch(error => {
                    console.error('Error checking existing booking:', error);
                  });
              } else {
                console.error('Driver state not found');
              }
            });
          } else {
            console.error('No full name found for userId:', userId);
          }
        } else {
          console.error('No data found for userId:', userId);
        }
      });
    });
  }
  
  generateUniqueId() {
    // Simple unique ID generator
    return 'ride-' + Math.random().toString(36).substr(2, 9);
  }




  showBookingAlert() {
    this.alertController.create({
      header: 'Booking Request',
      message: `do you want to send booking request to ${this.passenger.name }?`,
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Cancel clicked');
          }
        }, {
          text: 'Send',
          handler: () => {
            console.log('Send clicked');
            this.sendRideRequest();
            // Add logic to send booking request to the driver
           
          }
        }
      ]
    }).then(alert => {
      alert.present();
    });
  }


  ngOnDestroy() {
    if (this.routerSubscription) {
      this.routerSubscription.unsubscribe();
    }
  }}
