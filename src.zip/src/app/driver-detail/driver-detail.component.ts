import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';
import { ActionSheetController, Platform } from '@ionic/angular';
import { take } from 'rxjs/operators';
import { AuthService } from '../auth/auth.service';
import { DriverDetail } from './driver-detail.model';
import { HttpClient } from '@angular/common/http';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-driver-detail',
  templateUrl: './driver-detail.component.html',
  styleUrls: ['./driver-detail.component.scss'],
})
export class DriverDetailComponent implements OnInit {
  selectedImage: string | undefined;
  driverDetailForm: FormGroup; 
  driverDetail: DriverDetail = new DriverDetail(); 
  userId: string;
  selectedYear: string;
  form: FormGroup;
  private authSub: Subscription;

  carModels: string[] = [
    'Honda',
    'Toyota',
    'Ford',
    'Chevrolet',
    'BMW',
    'Audi',
    'Mercedes-Benz',
    'Tesla',
    'Hyundai',
    'Nissan'
  ];

  constructor(
    private platform: Platform,
    private router: Router,
    private fb: FormBuilder,
    private authService: AuthService,
    private http: HttpClient,
    public actionSheetController: ActionSheetController, private formBuilder: FormBuilder
  ) {
    this.form = this.formBuilder.group({
      year: [''] // Initialize your form control
    });
  }

  ngOnInit(): void {
    // Get userId from AuthService
    this.authSub = this.authService.userIsAuthenticated.subscribe(isAuth => {
      if (!isAuth) {
        this.resetForm();
      }
    });

    this.authService.userId.pipe(take(1)).subscribe(userId => {
      this.userId = userId;
      console.log('User ID:', this.userId);  // Log user ID for debugging
      this.initializeForm();
    });
  }

  initializeForm() {
    // Initialize the form group with default values or empty values
    this.driverDetailForm = this.fb.group({
      car_image: [null],
      model: [null, Validators.required],
      type: [null, Validators.required],
      color: [null, Validators.required],
      year: [null, Validators.required],
      license_plate: [null, Validators.required],
      driving_license: [null, [Validators.required, Validators.pattern(/^[A-Z]\d{4}-\d{5}-\d{5}$/)]], // Pattern for the license format
    });
  }

  // Convenience getter for easy access to form fields
  get f() { return this.driverDetailForm.controls; }

  // Function to update the selected year
  updateYear(event) {
    this.selectedYear = event.detail.value;
  }

  onSubmit() {
    // Stop here if form is invalid
    if (this.driverDetailForm.invalid) {
      return;
    }

    // Assign form values to the driver detail object
    this.driverDetail.car_image = this.driverDetailForm.value.car_image;
    this.driverDetail.model = this.driverDetailForm.value.model;
    this.driverDetail.type = this.driverDetailForm.value.type;
    this.driverDetail.color = this.driverDetailForm.value.color;
    this.driverDetail.year = this.driverDetailForm.value.year;
    this.driverDetail.license_plate = this.driverDetailForm.value.license_plate;
    this.driverDetail.driving_license = this.driverDetailForm.value.driving_license;

    // Ensure userId is set
    if (this.userId) {
      this.driverDetail.userId = this.userId;

      // Make an HTTP POST request to save driver detail data
      this.http.post(`https://driveshare-c4036-default-rtdb.firebaseio.com/driverDetails/${this.userId}.json`, this.driverDetail)
        .subscribe(
          (response: any) => {
            // Handle success
            console.log('POST request successful:', response);
            
            this.router.navigate(['/driver-home']);
          },
          (error) => {
            // Handle error
            console.error('Error making POST request:', error);
          }
        );

      // Reset the form
      this.driverDetailForm.reset();
    } else {
      console.error('User ID is not available');
    }
  }

  async selectImage() {
    if (this.platform.is('capacitor') || this.platform.is('hybrid') || this.platform.is('desktop')) {
      try {
        const image = await Camera.getPhoto({
          quality: 90,
          allowEditing: false,
          resultType: CameraResultType.DataUrl,
          source: CameraSource.Prompt, // This will give the user an option to select from gallery or take a photo
        });

        this.resizeImage(image.dataUrl, 500, 500).then(resizedImage => {
          this.selectedImage = resizedImage;
          this.driverDetailForm.patchValue({ car_image: this.selectedImage });
        });

      } catch (error) {
        console.error('Error capturing image:', error);
      }
    } else {
      // Fallback for web testing
      this.selectImageWeb();
    }
  }

  async takePicture() {
    if (this.platform.is('capacitor') || this.platform.is('hybrid') || this.platform.is('desktop') || this.platform.is('mobileweb')) {
      try {
        const image = await Camera.getPhoto({
          quality: 90,
          allowEditing: false,
          resultType: CameraResultType.DataUrl,
          source: CameraSource.Camera, // This will directly open the camera
        });

        this.resizeImage(image.dataUrl, 500, 500).then(resizedImage => {
          this.selectedImage = resizedImage;
          this.driverDetailForm.patchValue({ car_image: this.selectedImage });
        });

      } catch (error) {
        console.error('Error capturing image:', error);
      }
    } else {
      console.error('Camera is not available on this platform');
    }
  }

  selectImageWeb() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (event: any) => {
      const file = event.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          const imageDataUrl = e.target.result as string;
          this.resizeImage(imageDataUrl, 500, 500).then(resizedImage => {
            this.selectedImage = resizedImage;
            this.driverDetailForm.patchValue({ car_image: this.selectedImage });
          });
        };
        reader.readAsDataURL(file);
      }
    };
    input.click();
  }

  resizeImage(dataUrl: string, maxWidth: number, maxHeight: number): Promise<string> {
    return new Promise((resolve) => {
      const img = new Image();
      img.src = dataUrl;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        // Calculate the new dimensions while preserving the aspect ratio
        if (width > maxWidth) {
          height *= maxWidth / width;
          width = maxWidth;
        }
        if (height > maxHeight) {
          width *= maxHeight / height;
          height = maxHeight;
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);

        resolve(canvas.toDataURL('image/jpeg', 0.8)); // Adjust the quality as needed
      };
    });
  }


  resetForm() {
    // Reset the form controls and clear the selected image
    this.driverDetailForm.reset();
    this.selectedImage = undefined;
  }
  
}
