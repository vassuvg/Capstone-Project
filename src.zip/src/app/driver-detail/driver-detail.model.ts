export class DriverDetail {
    public car_image: string;
    public model : string;
    public type: string;
    public color: string;
    public year: string;
    public license_plate: string;
    public driving_license: string;
    userId: any;
 }
 

 //model, type , color , year, picture , license plate , driving license 