import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { DOCUMENT } from '@angular/common';
import { DriverRideDataService } from 'src/app/driver-ridedata/driver-ridedata.service';
import { AuthService } from 'src/app/auth/auth.service';
import { Subscription } from 'rxjs';
import { filter, switchMap, take } from 'rxjs/operators';
import { AlertController, NavController } from '@ionic/angular';
import { RideService } from '../passenger-rides-request/ride.service';
import { PassengerService } from '../passenger.service';
import { ProfileService } from 'src/app/profile/profile.service';
import { MatchedDriverService } from './matched-driver.service';
import { DriverRideData } from 'src/app/driver-ridedata/driver-ridedata.model';

@Component({
  selector: 'app-matched-driver-detail',
  templateUrl: './matched-driver-detail.component.html',
  styleUrls: ['./matched-driver-detail.component.scss'],
})
export class MatchedDriverDetailComponent implements OnInit, OnDestroy {
  driver: any;
  driverRideData: any = {};
  userId: string;
  AllRideData: any;
  private MyDriverData: any;
  xyz: string;
  private routerSubscription: Subscription;
  passengerData : any;
  abc: string;

  constructor(
    private router: Router,
    private driverRideDataService: DriverRideDataService,
    private authService: AuthService,
    private http: HttpClient,
    @Inject(DOCUMENT) private document: Document,
    private alertController: AlertController, private navCtrl : NavController, private rideService : RideService, private passengerService: PassengerService, private profileService: ProfileService, private matchedDriverService: MatchedDriverService
  ) {}

  ngOnInit() {
    this.routerSubscription = this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe(() => {
        const navigation = this.router.getCurrentNavigation();
        if (navigation && navigation.extras.state) {
          this.driver = navigation.extras.state['driver'];
          console.log(this.driver);
          this.xyz = this.driver.driverUserId;
          this.abc = this.driver.driverRideId;
          console.log(this.xyz);
          console.log(this.abc);
          this.GetFilteredAccount();
        }
      });

    // Initial load
    const navigation = this.router.getCurrentNavigation();
    if (navigation && navigation.extras.state) {
      this.driver = navigation.extras.state['driver'];
      console.log(this.driver);
      console.log(this.driver.Passengerstate)
      this.xyz = this.driver.driverUserId;
      this.abc = this.driver.driverRideId;
      console.log(this.xyz);
      console.log(this.abc);
      this.GetFilteredAccount();
    }

    this.authService.userId.pipe(
      switchMap(userId => this.passengerService.getPassengerData(userId))
    ).subscribe(data => {
      this.passengerData = data;
      this.userId = data.userId; // assuming userId is a property of passengerData
    });
  }

  
  GetFilteredAccount() {
    this.matchedDriverService.getDriverRideDetails(this.xyz, this.abc).subscribe(
      (data: DriverRideData) => {
        if (data) {
          this.driverRideData = data;
          console.log('Driver Ride Data:', this.driverRideData);
        } else {
          console.error('No matching driver ride data found');
        }
      },
      error => {
        console.error('Error fetching driver ride data:', error);
      }
    );
  }
  
  ngOnDestroy() {
    if (this.routerSubscription) {
      this.routerSubscription.unsubscribe();
    }
  }
  checkExistingBooking(driverId: string, passengerId: string, passengerDepartureDate: string): Promise<boolean> {
    return new Promise((resolve, reject) => {
        this.http.get<any>('https://driveshare-c4036-default-rtdb.firebaseio.com/acceptedrides.json')
            .subscribe(rides => {
                if (rides) {
                    console.log('Rides data:', rides);

                    let existingRide = null;
                    for (const tableId in rides) {
                        if (rides.hasOwnProperty(tableId)) {
                            const ride = rides[tableId];
                            console.log('Checking ride:', ride);
                            
                            // Ensure the dates match exactly
                            if (ride.driverId === driverId && 
                                ride.passengerId === passengerId && 
                                ride.driverDepartureDate === passengerDepartureDate) {
                                existingRide = ride;
                                break;
                            }
                        }
                    }

                    console.log('Existing Ride:', existingRide);
                    resolve(!!existingRide); // Resolve with true if an existing ride is found, otherwise false
                } else {
                    resolve(false); // Resolve with false if no rides are found
                }
            }, error => {
                reject(error); // Reject the promise in case of an error
            });
    });
}

sendRideRequest() {
    this.authService.userId.pipe(take(1)).subscribe(userId => {
        this.profileService.getPassengerData(userId).pipe(take(1)).subscribe(data => {
            if (data) {
                const tableId = Object.keys(data)[0];
                const fullName = data[tableId]?.fullName;

                if (fullName) {
                    this.passengerService.getPassengerState().pipe(take(1)).subscribe(passengerState => {
                        console.log('Passenger State:', passengerState);

                        if (passengerState) {
                            // Ensure dates match before making the booking request
                            this.checkExistingBooking(this.driver.driverUserId, userId, passengerState.departureDate)
                                .then(isBooked => {
                                    if (isBooked) {
                                        this.alertController.create({
                                            header: 'Already Booked',
                                            message: `You have already booked a ride with ${this.driver.name} on ${passengerState.departureDate}.`,
                                            buttons: ['OK']
                                        }).then(alert => alert.present());
                                    } else {
                                        const rideRequest = {
                                            PassengerRideID: passengerState.PassengerRideID,
                                            driverRideId: this.driver.driverRideId,
                                            driverId: this.driver.driverUserId,
                                            passengerName: fullName,
                                            driverName: this.driver.name,
                                            origin: passengerState.pickupLocation,
                                            destination: passengerState.dropoffLocation,
                                            departureDate: passengerState.departureDate,
                                            departureTime: passengerState.departureTime,
                                            seats: passengerState.seats,
                                            luggage: passengerState.luggage,
                                            additionalDetails: passengerState.additionalDetails,
                                            passengerId: userId
                                        };

                                        console.log('Ride Request:', rideRequest);
                                        this.rideService.sendRideRequest(rideRequest).subscribe(response => {
                                            console.log('Ride request sent:', response);
                                        });
                                    }
                                })
                                .catch(error => {
                                    console.error('Error checking existing booking:', error);
                                });
                        } else {
                            console.error('Passenger state not found');
                        }
                    });
                } else {
                    console.error('No full name found for userId:', userId);
                }
            } else {
                console.error('No data found for userId:', userId);
            }
        });
    });
}


  showBookingAlert() {
    this.alertController.create({
      header: 'Booking Request',
      message: `Do you want to send a booking request to ${this.driver.name}?`,
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Cancel clicked');
          }
        }, {
          text: 'Send',
          handler: () => {
            console.log('Send clicked');
            this.sendRideRequest();
          }
        }
      ]
    }).then(alert => {
      alert.present();
    });
  }
  
}
