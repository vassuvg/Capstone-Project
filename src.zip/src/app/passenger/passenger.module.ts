import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { RouterModule } from '@angular/router';

import { PassengerComponent } from './passenger.component';
import { PassengerDetailComponent } from './passenger-detail/passenger-detail.component';
import { ViewrideDetailComponent } from './viewride-detail/viewride-detail.component';
import { MatchedDriverDetailComponent } from './matched-driver-detail/matched-driver-detail.component';
import { PassengerRidesRequestComponent } from './passenger-rides-request/passenger-rides-request.component';

@NgModule({
  declarations: [
    PassengerComponent,
    PassengerDetailComponent,
    ViewrideDetailComponent,
    MatchedDriverDetailComponent, PassengerRidesRequestComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    IonicModule,
    RouterModule.forChild([
      {
        path: '',
        component: PassengerComponent
      }
    ])
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class PassengerPageModule {}
