import { AfterViewInit, Component, NgZone, ViewChild } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { AlertController } from '@ionic/angular'; 
import { Router } from '@angular/router';
import { PassengerService } from './passenger.service';
import { DriverService } from '../driver/driver.service';
import { HttpClient } from '@angular/common/http';
import { AuthService } from '../auth/auth.service';

export const PATH_ELIGIBILITY_OFFSET = 5;

export type LatLng = { lat: number, lng: number };

declare var google;
declare var AdvancedMarkerElement: any;
@Component({
  selector: 'app-passenger',
  templateUrl: './passenger.component.html',
  styleUrls: ['./passenger.component.scss'],
})
export class PassengerComponent implements AfterViewInit {
  pickupPlaces$: Observable<any[]>;
  dropoffPlaces$: Observable<any[]>;
  pickupQuery: '';
  dropoffQuery: '';
  distance : string;
  duration : string;
  map: any;
  pickupMarker: any;
  dropoffMarker: any;
  userId: string;
  price: number;
  destinationOffsetStep = 0;

  @ViewChild('mapElement', {static: false}) mapElement;
  directionsService = new google.maps.DirectionsService();
  directionsRenderer = new google.maps.DirectionsRenderer();
  constructor(private zone: NgZone, private alertController: AlertController, private router: Router, private passengerService: PassengerService , private driverService: DriverService, private http : HttpClient, private authService: AuthService) {} // Inject AlertController
 

  async presentAlert(message: string) {
    const alert = await this.alertController.create({
      header: 'Alert',
      message: message,
      buttons: ['OK']
    });

    await alert.present();
  }

  onPickupSearchChange(event) {
    this.pickupQuery = event.detail.value;
    if (this.pickupQuery.length > 0) {
      this.getPickupPlaces();
    } else {
      this.pickupPlaces$ = null;
    }
  }

  onDropoffSearchChange(event) {
    this.dropoffQuery = event.detail.value;
    if (this.dropoffQuery.length > 0) {
      this.getDropoffPlaces();
    } else {
      this.dropoffPlaces$ = null;
    }
  }

  getPickupPlaces() {
    this.pickupPlaces$ = new Observable(observer => {
      try {
        let service = new google.maps.places.AutocompleteService();
        service.getPlacePredictions(
          {
            input: this.pickupQuery,
            componentRestrictions: { country: 'CA'}
          },
          (predictions) => {
            this.zone.run(() => {
              if (predictions) {
                const mappedPredictions = predictions.map(prediction => ({
                  title: prediction.structured_formatting.main_text,
                  address: prediction.description,
                }));
                observer.next(mappedPredictions);
                observer.complete();
              }
            });
          }
        );
      } catch (e) {
        observer.error(e);
      }
    });
  }

  getDropoffPlaces() {
    this.dropoffPlaces$ = new Observable(observer => {
      try {
        let service = new google.maps.places.AutocompleteService();
        service.getPlacePredictions(
          {
            input: this.dropoffQuery,
            componentRestrictions: { country: 'CA'}
          },
          (predictions) => {
            this.zone.run(() => {
              if (predictions) {
                const mappedPredictions = predictions.map(prediction => ({
                  title: prediction.structured_formatting.main_text,
                  address: prediction.description,
                }));
                observer.next(mappedPredictions);
                observer.complete();
              }
            });
          }
        );
      } catch (e) {
        observer.error(e);
      }
    });
  }

  // async onPlaceSelect(xx, place) {
  //   var directionsService = new google.maps.DirectionsService();
  //   var directionsRenderer = new google.maps.DirectionsRenderer();
  //   var chicago = new google.maps.LatLng(41.850033, -87.6500523);
  //   var mapOptions = {
  //     zoom:7,
  //     center: chicago
  //   }
  //   var map = new google.maps.Map(document.getElementById('map'), mapOptions);
  //   directionsRenderer.setMap(map);
  //   directionsRenderer.setPanel(document.getElementById('directionsPanel'));
  //   var request = {
  //     origin: this.pickupQuery,
  //     destination: place.address,
  //     travelMode: 'DRIVING'
  //   };
  //   directionsService.route(request, function(response, status) {
  //     if (status == 'OK') {
  //       directionsRenderer.setDirections(response);
  //     }
  //   });
  // }



  async onPlaceSelect(locationType: 'pickup' | 'dropoff', place: any) {
    if (locationType === 'pickup') {
      this.pickupQuery = place.address;
      //this.pickupPlaces$ = null;
      this.passengerService.setPickupQuery(this.pickupQuery)
      this.pickupPlaces$ = null;
    } else {
      const routes = this.driverService.availableRoutes;
      const userName = this.driverService.userNames;
      //console.log(routes)
      //console.log(userName)
      for (const route of routes) {
        await this.getEligibleRoutes(route);
        //console.log(await this.getEligibleRoutes(route))
      }

  
      this.dropoffQuery = place.address;
      this.passengerService.setDropoffQuery(this.dropoffQuery)
      // Calculate distance between pickup and dropoff locations
      const distanceMatrixService = new google.maps.DistanceMatrixService();
      distanceMatrixService.getDistanceMatrix({
        origins: [this.pickupQuery],
        destinations: [this.dropoffQuery],
        travelMode: google.maps.TravelMode.DRIVING,
      }, (response, status) => {
        if (status === 'OK' && response.rows && response.rows.length > 0) {
          const distance = response.rows[0].elements[0].distance.value; // Distance in meters
          const distanceInKm = distance / 1000; // Convert distance to kilometers
          // Check if dropoff is within 800 km radius and distance is at least 7 km
          if (distanceInKm <= 800 && distanceInKm >= 7) {
            // Dropoff location is valid
            this.dropoffPlaces$ = null;
            // Calculate and display route on the map
            this.calculateAndDisplayRoute();
  
            this.distance = response.rows[0].elements[0].distance.text; // Store distance as component property
            this.duration = response.rows[0].elements[0].duration.text;
            this.price = this.calculatePrice(distanceInKm);
          } else {
            // Dropoff location is not within the radius or minimum distance requirement
            this.presentAlert('Drop-off location must be within a 800 km radius and at least 7 km away from the pick-up location.');
            this.dropoffQuery = ''; // Clear the dropoff query
            this.dropoffPlaces$ = null;
          }
        } else {
          // Error occurred while calculating distance
          this.presentAlert('Error occurred while calculating distance. Please try again.');
          this.dropoffQuery = ''; // Clear the dropoff query
        }
      });
    }
  }
  calculatePrice(distanceInKm: number): number {
    return distanceInKm * 0.6;
  }
  

   private async getEligibleRoutes(request) {
    var directionsService = new google.maps.DirectionsService();
    


    await directionsService.route(request, async (response, status) => {
      if (status == 'OK') {
        const distance = response.routes[0].legs[0].distance.value / 1000;
        const path: Array<any> = response.routes[0].legs[0].steps.reduce((acc, step) => acc.concat(...step.path), []);
        const stepOffset = (path.length / distance) * PATH_ELIGIBILITY_OFFSET;
        let isSourceEligible, isDestEligible;
        
        let routeIndex = -1; // Variable to store the index of the route
            
        // Iterate over the available routes
        for (let i = 0; i < this.driverService.availableRoutes.length; i++) {
            const route = this.driverService.availableRoutes[i];
            // Check if the current route matches the request
            if (route.origin === request.origin && route.destination === request.destination) {
                routeIndex = i; // Assign the index of the route

                console.log(routeIndex)
                break; // Exit the loop once the route is found

            }
        }
        for (let i = 0; i <= path.length; i += stepOffset) {
          this.destinationOffsetStep = i;
          isSourceEligible = await this.checkDistanceEligibility(path[Math.round(i)].toJSON(), this.pickupQuery);
          if (isSourceEligible) {
            break;
          }
        }
        for (let i = this.destinationOffsetStep; i <= path.length; i += stepOffset) {
          
          isDestEligible = await this.checkDistanceEligibility(path[Math.round(i)].toJSON(), this.dropoffQuery);
          if (isDestEligible) {
            break;
          }
        }
        if (isSourceEligible && isDestEligible && routeIndex !== -1) {
          
         // const routeName = this.driverService.routeNames[routeIndex]; 
          console.log(`You are eligible for ${this.driverService.userNames[routeIndex]}`)
         
        
        }
      }
    });
  }

  // pointA: Driver
  // pointB: Source/Destination of passenger
  private async checkDistanceEligibility(pointA: LatLng, pointB: string): Promise<boolean> {
    const x = new google.maps.LatLng(pointA.lat, pointA.lng);
    console.log(x);
    console.log(pointB)
    var service = new google.maps.DistanceMatrixService();
    console.log(service)
    return service.getDistanceMatrix(
      {
        origins: [x],
        destinations: [pointB],
        travelMode: 'DRIVING',
        
      }).then((response, status) => {
        if(!response.rows[0].elements[0].distance){ return false}
        const dist = response.rows[0].elements[0].distance.value / 1000;
        console.log(dist);
        return dist <= PATH_ELIGIBILITY_OFFSET;
      });
  }

  //ngAfterViewInit() {
    //this.loadMapWithDirection();
  //}
  ngAfterViewInit() {
    this.loadMapWithDirection();
  
    // Subscribe to user ID from AuthService
    this.authService.userId.subscribe(id => {
      this.userId = id;
      // Reset pickup and dropoff queries when user ID changes
      this.pickupQuery = '';
      this.dropoffQuery = '';
  
      // Clear existing markers on the map
      this.clearMarkers();
    });
  }
  
  clearMarkers() {
    if (this.pickupMarker) {
      this.pickupMarker.setMap(null);
      this.pickupMarker = null;
    }
    if (this.dropoffMarker) {
      this.dropoffMarker.setMap(null);
      this.dropoffMarker = null;
    }
  }
  


  loadMapWithDirection() {
    this.map = new google.maps.Map(this.mapElement.nativeElement, {
      zoom: 10,
      center: { lat: 43.731548, lng: -79.762421},
    });

    // Create DirectionsRenderer with suppressMarkers set to true
    this.directionsRenderer = new google.maps.DirectionsRenderer({
      suppressMarkers: true,
      polylineOptions: {
        strokeColor: 'darkgreen', 
      }
    });
    this.directionsRenderer.setMap(this.map);
  }calculateAndDisplayRoute() {
    if (!this.pickupQuery || !this.dropoffQuery) {
      this.presentAlert('Please enter both pickup and dropoff locations.');
      return;
    }
  
    this.directionsService.route({
      origin: this.pickupQuery,
      destination: this.dropoffQuery,
      travelMode: google.maps.TravelMode.DRIVING,
    })
    .then((response) => {
      if (response && response.status === 'OK') {
        // Set directions on the map
        this.directionsRenderer.setDirections(response);
  
        // Remove existing pickup and drop-off markers if they exist
        if (this.pickupMarker) {
          this.pickupMarker.setMap(null);
        }
        if (this.dropoffMarker) {
          this.dropoffMarker.setMap(null);
        }
  
        // Add markers for pickup and drop-off locations
        const pickupLocation = response.routes[0].legs[0].start_location;
        const dropoffLocation = response.routes[0].legs[0].end_location;
  
        // Marker for pickup location
        this.pickupMarker = new google.maps.Marker({
          map: this.map,
          position: pickupLocation,
          icon: {
            url: "assets/car.png",
            scaledSize: new google.maps.Size(50, 50),
          },
          title: "Pickup Location",
        });
  
        // Marker for drop-off location
        this.dropoffMarker = new google.maps.Marker({
          map: this.map,
          position: dropoffLocation,
          icon: {
            url: "assets/car.png",
            scaledSize: new google.maps.Size(50, 50),
          },
          title: "Drop-off Location",
        });
        this.pickupMarker.setMap(this.map);
        this.dropoffMarker.setMap(this.map);
      } else {
        // Handle error or no route found
        this.presentAlert("No route found");
      }
    })
    .catch((e) => this.presentAlert("Directions request failed due to " + e.message));
  }

  onNewAlert() {
  /*  console.log(this.pickupQuery, this.dropoffQuery);
    
    // Save pickup and dropoff queries using PassengerService
   // this.passengerService.setPickupQuery(this.pickupQuery);
    //this.passengerService.setDropoffQuery(this.dropoffQuery);

    //this.router.navigate(['/passenger-detail']);
      // Save pickup and dropoff queries to Firebase Realtime Database using HttpClient
      
      const pickupData = {
        userId: this.userId,
        location: this.pickupQuery
      };


    
  const dropoffData = {
    userId: this.userId,
    location: this.dropoffQuery
  };

      


      this.http.post(
        `https://driveshare-c4036-default-rtdb.firebaseio.com/pickupLocations/${this.userId}.json`,
        //{ userId: this.userId,location: this.pickupQuery } 
        pickupData
      ).subscribe(response => {
        console.log('Pickup location saved successfully:', response);
      }, error => {
        console.error('Error saving pickup location:', error);
      });
  
      this.http.post(
        `https://driveshare-c4036-default-rtdb.firebaseio.com/dropoffLocations/${this.userId}.json`,
       // { userId: this.userId,location: this.dropoffQuery }
      dropoffData
       ).subscribe(response => {
        console.log('Dropoff location saved successfully:', response);
      }, error => {
        console.error('Error saving dropoff location:', error);
      });
  
      // Navigate to passenger detail page
      this.router.navigate(['/passenger-detail']);
   
    */
   
   this.passengerService.setPickupQuery(this.pickupQuery);

     this.passengerService.setDropoffQuery(this.dropoffQuery);
     this.router.navigate(['/passenger-detail']);
    }
    
    
goToHomePage(): void {
   this.router.navigate(['/home']);
  }

  goToDriverPage(): void {
    this.router.navigate(['/driver-detail']);
  }

}
