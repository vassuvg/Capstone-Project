import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, forkJoin, map } from 'rxjs';
import { ProfileService } from '../profile/profile.service';

@Injectable({
  providedIn: 'root'
})
export class PassengerService {
  /*pickupQuery: string;
  dropoffQuery: string;

  constructor() { }

  setPickupQuery(query: string) {
    this.pickupQuery = query;
  }

  setDropoffQuery(query: string) {
    this.dropoffQuery = query;
  }

  getPickupQuery() {
    return this.pickupQuery;
  }

  getDropoffQuery() {
    return this.dropoffQuery;
  }
*/

private baseUrl = 'https://driveshare-c4036-default-rtdb.firebaseio.com';

private passengerStateSubject = new BehaviorSubject<any>(null);
passengerState$ = this.passengerStateSubject.asObservable();


availableRoutes : any[] = [];
userNames: string[] = [];
userImages: string[] = [];
userId: string [] = [];
PassengerRiderID: string[] = [];
departureDates: string[] = [];


private pickupQuery = new BehaviorSubject<string>(null);
  private dropoffQuery = new BehaviorSubject<string>(null);


  constructor (private http : HttpClient, private profileService : ProfileService)
  {
    this.initializeRoutes();
  }
  
  setPickupQuery(pickup: string) {
    if (pickup) {
      this.pickupQuery.next(pickup);
    } else {
      this.pickupQuery.next(null);
    }
  }

  getPickupQuery() {
    return this.pickupQuery.asObservable();
  }

  setDropoffQuery(dropoff: string) {
    if (dropoff) {
      this.dropoffQuery.next(dropoff);
    } else {
      this.dropoffQuery.next(null);
    }
  }

  getDropoffQuery() {
    return this.dropoffQuery.asObservable();
  }

  getCurrentPickupQuery() {
    return this.pickupQuery.getValue();
  }

  getCurrentDropoffQuery() {
    return this.dropoffQuery.getValue();
  }
  
 // getPickupLocation(): Observable<any> {
   // return this.http.get(`https://driveshare-c4036-default-rtdb.firebaseio.com/driverpickupLocations.json`);
  //}

 /* getPickupLocation(userId: string, driverId: string): Observable<string> {     
    return this.http.get<string>(`https://driveshare-c4036-default-rtdb.firebaseio.com/driverpickupLocations/${userId}/${driverId}/location.json`); 
    
  }
  

  getDropoffLocation(userId: string, driverId: string): Observable<string> {
    return this.http.get<string>(`https://driveshare-c4036-default-rtdb.firebaseio.com/driverdropoffLocations/${userId}/${driverId}/location.json`);
  }
*/

 getPickupLocation(): Observable<string> {     
    return this.http.get<string>(`https://driveshare-c4036-default-rtdb.firebaseio.com/passengerDetails.json`); 
    
  }
  

  getDropoffLocation(): Observable<string> {
    return this.http.get<string>(`https://driveshare-c4036-default-rtdb.firebaseio.com/passengerDetails.json`);
  }

  getPassengerRideId(){
    return this.http.get<string>(`https://driveshare-c4036-default-rtdb.firebaseio.com/passengerDetails.json`);
  }

/*
  
  initializeRoutes() {
    forkJoin({
      pickupLocation: this.getPickupLocation(),
      dropoffLocation: this.getDropoffLocation(),
      departureDate: this.getDropoffLocation(),
      userName: this.profileService.getProfileName(),
      userImage: this.profileService.getProfileName(), 
      passengerUserId : this.profileService.getProfileName(),
      PassengerRiderID : this.getPassengerRideId()
    }).subscribe(
      ({ pickupLocation, dropoffLocation, userName, userImage, passengerUserId }) => {
        this.availableRoutes = Object.keys(pickupLocation).reduce((acc, key) => {
          if (pickupLocation[key] && dropoffLocation[key]) {
            acc.push({
              //userName: (Object.values(userName[key])[0] as any).fullName,
              origin: (Object.values(pickupLocation[key])[0] as any).pickupLocation,
              destination: (Object.values(dropoffLocation[key])[0] as any).dropoffLocation,
              travelMode: 'DRIVING'
            });
            this.userNames.push((Object.values(userName[key])[0] as any).fullName);
            this.userImages.push((Object.values(userImage[key])[0] as any).user_image);
            this.userId.push((Object.values(passengerUserId[key])[0] as any).userId);

          }
          return acc;
        }, []);

        console.log(this.userNames);
        console.log(this.availableRoutes);
        // Update any relevant observables or properties here
        // For example, if you have a BehaviorSubject for availableRoutes, you can update it
      },
      error => {
        console.error('Error loading routes', error);
      }
    );
  }
  */



  initializeRoutes() {
    forkJoin({
      pickupLocation: this.getPickupLocation(),
      dropoffLocation: this.getDropoffLocation(),
      departureDate: this.getDropoffLocation(),
      userName: this.profileService.getProfileName(),
      userImage: this.profileService.getProfileName(), 
      passengerUserId : this.profileService.getProfileName(),
      PassengerRiderID : this.getPassengerRideId()
    }).subscribe(
      ({
        pickupLocation,
        dropoffLocation,
        userName,
        userImage,
        passengerUserId,
        departureDate,
        PassengerRiderID,
      }) => {
        this.availableRoutes = Object.keys(passengerUserId).reduce((acc, key) => {
          if (pickupLocation[key] && dropoffLocation[key]) {
            const passengerRideIds = Object.keys(PassengerRiderID[key]);
            passengerRideIds.forEach((rideKey) => {
              const ride = PassengerRiderID[key][rideKey];
            acc.push({
              origin: ride.pickupLocation,
              destination: ride.dropoffLocation,
              travelMode: 'DRIVING'
            });
            
        this.departureDates.push(ride.departureDate);
        this.userNames.push((Object.values(userName[key])[0] as any).fullName);
        this.userImages.push((Object.values(userImage[key])[0] as any).user_image);
        this.userId.push(ride.userId);
        this.PassengerRiderID.push(rideKey);
          });

 
          }
          return acc;
        }, []);

        console.log("Available Routes:", this.availableRoutes);
        console.log("Passenger Names:", this.userNames);
        console.log("Passenger departure date:", this.departureDates);
        console.log("Passenger User ID:", this.userId);
       // console.log("Passenger User Image:", this.userImages);
        console.log("Passenger Rider ID:", this.PassengerRiderID);


      },
      (error) => {
        console.error('Error loading routes', error);
      }
    );
  }

  getPassengerData(userId: string): Observable<any> {
    const url = `${this.baseUrl}/passengerDetails/${userId}.json`;
    return this.http.get<any>(url).pipe(
      map(data => {
        const keys = Object.keys(data);
        if (keys.length > 0) {
          return { tableId: keys[0], ...data[keys[0]] };
        }
        return null;
      })
    );
  }

   // Method to set the passenger state
   setPassengerState(state: any): void {
    this.passengerStateSubject.next(state);
  }

  // Method to get the current passenger state
  getPassengerState() {
    return this.passengerState$;
  }

}
