import { Component, OnInit } from '@angular/core';
import { RideService } from './ride.service';
import { HttpClient } from '@angular/common/http';
import { AlertController, NavController } from '@ionic/angular';
import { AuthService } from 'src/app/auth/auth.service';
import { Passenger } from '../passenger.model';
import { BookingComponent } from 'src/app/booking/booking.component';

@Component({
  selector: 'app-passenger-rides-request',
  templateUrl: './passenger-rides-request.component.html',
  styleUrls: ['./passenger-rides-request.component.scss'],
})
export class PassengerRidesRequestComponent implements OnInit {
  rideRequests: any[] = [];
  showDetails: { [key: string]: boolean } = {}; // Track visibility of details for each request
  driverId: string;
  userId: string;
  isDriver: boolean = false;
  constructor(
    private rideService: RideService,
    private authService: AuthService,
    private http: HttpClient,
    private navCtrl: NavController,
    private alertController: AlertController
  ) {}

  ngOnInit() {
    this.authService.userId.subscribe(userId => {
      this.driverId = userId;
      console.log(this.driverId);
      this.fetchRideRequests();
    });
  }

  fetchRideRequests() {
    this.rideService.getRideRequest().subscribe(requests => {
      console.log('Ride requests received:', requests);
      this.rideRequests = [];

      if (requests) {
        const keys = Object.keys(requests);
        for (let key of keys) {
          if (requests[key].driverId === this.driverId) {
            this.rideRequests.push({ id: key, ...requests[key] });
            this.showDetails[key] = false; // Initialize detail visibility
          }
        }
      }
    });
    console.log("filtered Requests",this.rideRequests)
  }

 


  toggleDetails(requestId: string) {
    this.showDetails[requestId] = !this.showDetails[requestId];
  }

  acceptRide(request: any) {
    // const booking = {
    //   driverId: request.driverId,
    //   passengerId: request.passengerId,
    //   rideId: request.rideId,
    //   passengerName: request.passengerName,
    //   driverName: request.driverName,
    //   origin: request.origin,
    //   destination: request.destination,
    //   departureDate: request.departureDate,
    //   departureTime: request.departureTime,
    //   seats: request.seats,
    //   luggage: request.luggage,
    //   additionalDetails: request.additionalDetails,
    // };
    const booking={
      driverId: request.driverId,
      passengerId: request.passengerId,
      PassengerRideID:request.PassengerRideID,
      rideId: request.rideId,
      driverRideId:request.driverRideId,
      driverDepartureDate: request.departureDate

    }
    

    console.log(booking);

    this.rideService.acceptRideRequest(booking).subscribe(
      async response => {
        console.log('Booking response:', response);

        // Delete the accepted ride request from riderequests.json
        this.rideService.deleteRideRequest(request.id).subscribe(
          async () => {
            console.log('Ride request deleted');
            
            // Remove the accepted request from the local list
            this.rideRequests = this.rideRequests.filter(r => r.id !== request.id);

            const alert = await this.alertController.create({
              header: 'Booking Successful',
              message: 'Thank you for booking the ride!',
              buttons: ['OK']
            });
            await alert.present();

            // Navigate to booking component
            this.navCtrl.navigateForward('/booking', {
              queryParams: {
                bookingId: booking.rideId
              }
            });
          },
          error => {
            console.error('Error deleting ride request:', error);
          }
        );
      },
      error => {
        console.error('Error posting booking:', error);
      }
    );
  }

  generateUniqueId() {
    // Simple unique ID generator
    return 'ride-' + Math.random().toString(36).substr(2, 9);
  }

  cancelRide(requestId: string) {
    this.rideRequests = this.rideRequests.filter(r => r.id !== requestId);
    console.log('Ride request cancelled');
  }
}
