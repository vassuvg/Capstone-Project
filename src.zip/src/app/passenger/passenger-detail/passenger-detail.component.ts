import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PassengerDetail } from './passenger-detail.model';
import { Router } from '@angular/router';
import { ActionSheetController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { AuthService } from 'src/app/auth/auth.service';
import { take } from 'rxjs/operators';
import { PassengerService } from '../passenger.service';

@Component({
  selector: 'app-passenger-detail',
  templateUrl: './passenger-detail.component.html',
  styleUrls: ['./passenger-detail.component.scss']
})
export class PassengerDetailComponent implements OnInit {
  passengerDetailForm: FormGroup;
  passengerDetail: PassengerDetail = new PassengerDetail(); // Initialize with model object
  userId: string;
  pickupQuery: string;
  dropoffQuery: string;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    public actionSheetController: ActionSheetController,
    private http: HttpClient,
    private authService: AuthService,
    private passengerService: PassengerService
  ) { }

  ngOnInit(): void {
    // Get userId from AuthService
    this.authService.userId.pipe(take(1)).subscribe(userId => {
      this.userId = userId;
      console.log('User ID:', this.userId);  // Log user ID for debugging
      this.initializeForm();

       // Get pickup and dropoff queries from PassengerStateService
 // Subscribe to pickup and dropoff queries
 this.passengerService.getPickupQuery().pipe(take(1)).subscribe(pickupQuery => {
  this.pickupQuery = pickupQuery;
  console.log('Pickup Query:', this.pickupQuery);
});

this.passengerService.getDropoffQuery().pipe(take(1)).subscribe(dropoffQuery => {
  this.dropoffQuery = dropoffQuery;
  console.log('Dropoff Query:', this.dropoffQuery);
});
       console.log('Pickup Query:', this.pickupQuery);
       console.log('Dropoff Query:', this.dropoffQuery);
    });
  }

  initializeForm() {
    // Initialize the form group with default values or empty values
    this.passengerDetailForm = this.fb.group({
      departureDate: [null, Validators.required],
      departureTime: [null, Validators.required],
      seats: [null, [Validators.required, Validators.min(1), Validators.max(3)]],
      luggage: [null, [Validators.required, Validators.min(0), Validators.max(3)]],
      additionalDetails: [null , Validators.required]

    });
  }

  // Convenience getter for easy access to form fields
  get f() { return this.passengerDetailForm.controls; }

  onSubmit() {
    // Stop here if form is invalid
    if (this.passengerDetailForm.invalid) {
      return;
    }

    // Assign form values to the passenger detail object
    this.passengerDetail.departureDate = this.passengerDetailForm.value.departureDate;
    this.passengerDetail.departureTime = this.passengerDetailForm.value.departureTime;
    this.passengerDetail.seats = this.passengerDetailForm.value.seats;
    this.passengerDetail.luggage = this.passengerDetailForm.value.luggage;
    this.passengerDetail.additionalDetails = this.passengerDetailForm.value.additionalDetails;

    this.passengerDetail.pickupLocation = this.pickupQuery;
    this.passengerDetail.dropoffLocation = this.dropoffQuery;


    console.log('Form Values:', this.passengerDetail); 


    // Ensure userId is set
    if (this.userId) {
      this.passengerDetail.userId = this.userId;

      // Make an HTTP POST request to save passenger detail data
      this.http.post(`https://driveshare-c4036-default-rtdb.firebaseio.com/passengerDetails/${this.userId}.json`, this.passengerDetail)
        .subscribe(
          (response: any) => {
            // Handle success

            console.log('POST request successful:', response);
             const Rideid =response.name
            // console.log(x)

            this.passengerService.setPassengerState({
              PassengerRideID:Rideid,
              departureDate: this.passengerDetail.departureDate,
              departureTime: this.passengerDetail.departureTime,
              seats: this.passengerDetail.seats,
              luggage: this.passengerDetail.luggage,
              additionalDetails: this.passengerDetail.additionalDetails,
              pickupLocation: this.passengerDetail.pickupLocation,
              dropoffLocation: this.passengerDetail.dropoffLocation
            });

            this.presentActionSheet();
          },
          (error) => {
            // Handle error
            console.error('Error making POST request:', error);
          }
        );

      // Reset the form
      this.passengerDetailForm.reset();
    } else {
      console.error('User ID is not available');
    }


  }

  async presentActionSheet() {
    const actionSheet = await this.actionSheetController.create({
      header: 'Ride posted',
      buttons: [
        {
          text: 'OK',
          handler: () => {
            this.router.navigate(['/passenger']); // Navigate back to passenger page
          }
        },
        {
          text: 'View Ride Details',
          handler: async () => {
            // Fetch data from the provided URLs
            try {
              /*const passengerDetailsUrl = `https://driveshare-c4036-default-rtdb.firebaseio.com/passengerDetails.json`;
              const pickupLocationsUrl = `https://driveshare-c4036-default-rtdb.firebaseio.com/pickupLocations.json`;
              const dropoffLocationsUrl = `https://driveshare-c4036-default-rtdb.firebaseio.com/dropoffLocations.json`;

              console.log('Fetching passenger details from:', passengerDetailsUrl);
              console.log('Fetching pickup locations from:', pickupLocationsUrl);
              console.log('Fetching dropoff locations from:', dropoffLocationsUrl);

              const passengerDetails = await this.http.get<any>(passengerDetailsUrl).toPromise();
              const pickupLocations = await this.http.get<any>(pickupLocationsUrl).toPromise();
              const dropoffLocations = await this.http.get<any>(dropoffLocationsUrl).toPromise();

              // Process the fetched data as needed
              console.log('Passenger Details:', passengerDetails);
              console.log('Pickup Locations:', pickupLocations);
              console.log('Dropoff Locations:', dropoffLocations);
*/
              // Navigate to view ride detail page
              this.router.navigate(['/viewride-detail']);
            } catch (error) {
              console.error('Error fetching data:', error);
              // Handle error
              const alert = await this.actionSheetController.create({
                header: 'Error',
                buttons: ['OK']
              });
              await alert.present();
            }
          }
        }
      ]
    });
    await actionSheet.present();
  }



}
