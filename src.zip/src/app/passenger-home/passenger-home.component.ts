import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
;

@Component({
  selector: 'app-passenger-home',
  templateUrl: './passenger-home.component.html',
  styleUrls: ['./passenger-home.component.scss'],
})
export class PassengerHomeComponent  implements OnInit {

  constructor(private router: Router
    ) { }

  ngOnInit() {}

  postRide() {
    this.router.navigate(['/passenger']);
  }

 // viewPendingRideRequests() {
   // this.router.navigate(['/driver-rides-request']);
  //}

  checkMyRides() {
    this.router.navigate(['/my-rides']);
  }

  bookedRides() {
    this.router.navigate(['/booking-passenger']);
  }

}
