// driver-myrides.component.ts
import { Component, OnInit, OnDestroy } from '@angular/core';
import { DriverMyRidesService } from './driver-myrides.service';
import { lastValueFrom, Subscription, take } from 'rxjs';
import { AuthService } from '../auth/auth.service';
import { Router } from '@angular/router';
import { SegmentChangeEventDetail } from '@ionic/angular';
import { IonSegmentCustomEvent } from '@ionic/core';
import { ChangeDetectorRef } from '@angular/core';


@Component({
  selector: 'app-driver-myrides',
  templateUrl: './driver-myrides.component.html',
  styleUrls: ['./driver-myrides.component.scss'],
})
export class DriverMyridesComponent implements OnInit, OnDestroy {
//x:any
  AllUserBookings: any;
  routeNames: string[] = [];
  private authSub: Subscription;
  private previousAuthState = false;
  selectedSegment: string = 'today';
  userId:string
KeysSet:any
  TodaysBookedRides:any
  TodaysUnbookedRides:any
  PastRides:any
  UpcomingRides:any={}
  KeysSet2:any
  activeIndex: number | null = null;
  FutureRides:any

  togglePassengers(index: number) {
    // If the clicked card is already active, set it to null (toggle off)
    // Otherwise, set the activeIndex to the clicked card index
    this.activeIndex = this.activeIndex === index ? null : index;
  }

  constructor(private driverRideService: DriverMyRidesService,private authService:AuthService, private router:Router, private cdr:ChangeDetectorRef) {}

  async ngOnInit() {
    this.authSub = this.authService.userIsAuthenticated.subscribe(isAuth => {
      if (!isAuth && this.previousAuthState !== isAuth) {
        this.router.navigateByUrl('/auth');
      }
      this.previousAuthState = isAuth;
    });
 
     this.authService.userId.pipe(take(1)).subscribe(userId => {
      this.userId = userId;
      console.log('User ID:', this.userId); // Log user ID for debugging

      //  this.initializeForm();
    });
      // this.getTodaysDate();
    this.AllUserBookings= this.getAllBookings(this.userId)
this.performActionBasedOnSegment("today");  
  }
//on init ended here
  

    // this method get triggered everytime the segment is changed and this just take the value of segment and store it in an variable
    //and of course trigger the func which does change the content according to the segment
    async onSegmentChange($event: IonSegmentCustomEvent<SegmentChangeEventDetail>) {
      this.AllUserBookings= this.getAllBookings(this.userId)
      this.selectedSegment = $event.detail.value.toString()
      console.log('Segment changed to:', this.selectedSegment);

      // Place your code here to handle segment changes
      await this.performActionBasedOnSegment(this.selectedSegment);  
      this.cdr.detectChanges();    }
  
  
  async performActionBasedOnSegment(selectedSegment: string) {
    switch(selectedSegment){
      case 'today':{
     
        const TodaysAllRides = await this.getDriverRideDetails(this.userId,selectedSegment);
        const TodaysAllRides2 = await this.getDriverRideDetails(this.userId,selectedSegment);

        console.log("All rides for Today ",TodaysAllRides);
        console.log("All booked rides for Today",this.AllUserBookings);
        
        //Removing All bookings which are not for today
        const x=this.RemoveUnrequiredkey(TodaysAllRides,this.AllUserBookings)

        //printing all booked rides
        console.log("After removing unrequired key which gives All user booking for today",x);
        const bookedRideIds=new Set<string>();
       Object.values(x).forEach(ride=> bookedRideIds.add(ride.driverRideId));
       console.log(bookedRideIds)

       const bookedRideIdsArray = Array.from(bookedRideIds);
       bookedRideIds.clear();

const TodaysUnbookedRides=this.RemoveUnrequiredKey2(TodaysAllRides,bookedRideIdsArray)
this.TodaysUnbookedRides=this.getObject(this.RemoveUnrequiredKey2(TodaysAllRides,bookedRideIdsArray))
console.log("UnBookedRideData",this.TodaysUnbookedRides)
Object.keys(TodaysUnbookedRides).map(key=> bookedRideIds.add(key))
const UnbookedRideIdsArray = Array.from(bookedRideIds);
bookedRideIds.clear()
console.log("UnbookedRideIdsArray",UnbookedRideIdsArray)
const BookedRideswithkeys=this.RemoveUnrequiredKey2(TodaysAllRides2,UnbookedRideIdsArray)
//this.TodaysBookedRides=this.getObject(this.RemoveUnrequiredKey2(TodaysAllRides2,UnbookedRideIdsArray))
console.log("BookedRideData",this.TodaysBookedRides);
console.log(BookedRideswithkeys)
console.log(bookedRideIdsArray)
Object.values(x).forEach(ride=> bookedRideIds.add(ride.driverRideId));
  let counter=1
  for (const ride of Object.values(x)) {
    if (bookedRideIds.has(ride.driverRideId)) {
      // Fetch passenger profile and add to BookedRideswithkeys
      const passengerProfile = await this.getPassengerProfile(ride.passengerId);
      BookedRideswithkeys[ride.driverRideId][`passengerId${counter}`] = this.getObject( passengerProfile);
      BookedRideswithkeys[ride.driverRideId][`DriverRideID`]=ride.driverRideId
      // BookedRideswithkeys[ride.driverRideId][PassengerRideID${counter}] = ride.PassengerRideID;
      counter++;
    }
  }

console.log(BookedRideswithkeys);
this.TodaysBookedRides=this.getObject(BookedRideswithkeys)   
console.log("UnBooked",this.TodaysUnbookedRides)
     
        
        break;
      }
      //All will show future rides
      case'all':{
       const allridesaftertoday= await this.getDriverRideDetails(this.userId,selectedSegment);
      //  console.log("All rides after today",allridesaftertoday);
       this.FutureRides=this.getObject( allridesaftertoday)
       console.log("FutureRides",this.FutureRides)
        break;
      }
      case 'past':{
        const PastRides=    await this.getDriverRideDetails(this.userId,selectedSegment);
        this.PastRides=this.getObject(PastRides)
        console.log("PastRides",this.PastRides);
        break;
      }
      
    }
  }

        




  getAllBookings(userID:string){
this.driverRideService.getAllBookings(userID).subscribe((x:any)=>{
this.AllUserBookings=x;
console.log("Alluserbookings",this.AllUserBookings)

},error=>{ console.log(error)})
}

async  getTodaysDate(){
    let today = new Date();
    let formattedDate = today.toISOString().split('T')[0];
    console.log("Formatted Date",formattedDate);
    return formattedDate;
  }
// async getDriverRideDetails(userid:string,Date:string,text:string): Promise<any>{
//  (await this.driverRideService.getDriverRideDatabyDate(userid, Date, text)).subscribe((x: any) => {
//     this.x = x;
//     console.log("Data", this.x);
//   });
// console.log(this.x)
//  return this.x;

// }
  
async getDriverRideDetails(userId: string, text: string): Promise<any> {
  const data = await lastValueFrom(this.driverRideService.getDriverRideDatabyDate(userId,  text));
  console.log("Data", data);
  return data;
}

 

  ngOnDestroy() {
   
  }





  goToPassengerPage(): void {
    // navigation logic
  }

  goToHomePage(): void {
    // navigation logic
  }



// //array2-array1
//  removeMatchingKeys(array1: { [key: string]: any }, array2: { [key: string]: any }): { [key: string]: any } {
//     // Create a set of keys from array1 for quick lookup
//     const keysSet = new Set(Object.keys(array1));
//     console.log("keyset",keysSet)
  
//     // Filter out items from array2 where the key matches any in the keysSet
//     const filteredArray2 = Object.entries(array2)
//       .filter(([key, value]) => !keysSet.has(key))
//       .reduce((acc, [key, value]) => {
//         acc[key] = value;
//         return acc;
//       }, {} as { [key: string]: any });
  
//     return filteredArray2;
//   }

//this method would remove all the booking Data from the array which is not on the desired day
//i.e. Array1: All Rides from today by the driver logged in
//Array2: All BookedRides of the driver logged in
//Array2-Array1 : Gives us All the Bookings for today 
  RemoveUnrequiredkey(array1: { [key: string]: any }, array2: { [key: string]: any }): { [key: string]: any }{
    this.KeysSet = new Set(Object.keys(array1));
    console.log("keyset",this.KeysSet)
    this.KeysSet2=new Set

    return Object.entries(array2)
    .filter(([key, value]) => this.KeysSet.has(value.driverRideId))
    .reduce((acc, [key, value]) => {
      acc[key] = value;
      console.log(value.driverRideId)
      this.KeysSet2.add(value.driverRideId)
      return acc;
    }, {} as { [key: string]: any });
  
  }
//used for Removing all the rides from Allrides which are booked 

//This func take an array of keys and removes those keys from the array you want to remove it from
  RemoveUnrequiredKey2(array1: { [key: string]: any }, keysToRemove: string[]): { [key: string]: any } {
    const x= array1
    for (const key of keysToRemove) {
      if (key in array1) {
        delete x[key];
      }
    }
  this.KeysSet2=null;
    return x;
  }



  //To give back object1 from [object object1] datatype
  getObject(array1: { [key: string]: any }){
return Object.keys(array1).map(key => array1[key])
  }


  //Get additional data required for booked Rides and merge additional data to the object
  // async addAdditionalData(rides: any[]): Promise<any[]> {
  //   const updatedRides = await Promise.all(rides.map(async ride => {
  //     const additionalData =  this.driverRideService.getpassengerprofile(ride.passengerId[0]).toPromise()
  //     const updatedAddData = this.getObject(additionalData) 
  //     console.log(updatedAddData)
  //     return { ...ride, ...updatedAddData[0] };
  //   }));

  //   return updatedRides;
  // }
  async addAdditionalData(rides: any[]): Promise<any[]> {
    console.log('Rides:', rides);  // Check the actual content and type of rides
    if (!Array.isArray(rides)) {
      throw new Error('The input rides is not an array!');
    }
    const updatedRides = await Promise.all(rides.map(async ride => {
      const additionalData = await this.driverRideService.getpassengerprofile(ride.passengerId).toPromise();
      return { ...ride, ...additionalData };
    }));

    return updatedRides;
  }

  async getPassengerProfile(passengerId: string): Promise<any> {
    try {
      const data = await this.driverRideService.getpassengerprofile(passengerId).toPromise();
      console.log('Fetched passenger data:', data);
      return data;
    } catch (error) {
      console.error('Error fetching passenger data:', error);
    }
  }
  

}