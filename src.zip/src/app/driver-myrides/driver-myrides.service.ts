import { Injectable, OnDestroy } from '@angular/core';
import { BehaviorSubject, Observable, Subscription } from 'rxjs';
import { ProfileService } from '../profile/profile.service';
import { AuthService } from '../auth/auth.service';
import { DriverInfoService } from '../driver-rideinfo/driver-rideinfo.service';
import { HttpClient, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class DriverMyRidesService {
  apiUrl:string="https://driveshare-c4036-default-rtdb.firebaseio.com"
  constructor(private authservice:AuthService, private http:HttpClient){
    
  }

    //service to get passenger userprofile
    getpassengerprofile(passengerid: string):Observable<any> {
      return this.http.get<any>(`${this.apiUrl}/profiles/${passengerid}.json`)
    }

  //service method to get all the booking for current user, this method will only work for driver 
  getAllBookings(userID: string): Observable<any> {
    // Construct query parameters
    const params = new HttpParams()
      .set('orderBy', '"driverId"')
      .set('equalTo', "${userID}")
      
      return this.http.get<any>(`${this.apiUrl}/acceptedrides.json`, { params });
  }

  //http req method to get all the rides posted by driver filtered by date  
    getDriverRideDatabyDate(userID:string,text:string):Observable<any>{ 
    // console.log(text)
    if(text==='today'){
      console.log("today Called")
      const newDate= new Date()
      // console.log("newDate",newDate)
      const newDate1=newDate.toISOString().split('T')[0]

      return  this.http.get<any>(`${this.apiUrl}/driverRideData/${userID}.json`,{params: new HttpParams()
        .set('orderBy', '"departureDate"')
        .set('equalTo', `"${newDate1}"`)}
        )
  }
    else if(text==='all'){
      console.log("all Called")
      const today = new Date();
      const date = new Date();
      date.setDate(today.getDate() + 1);
       // Format the date back to YYYY-MM-DD string
      const previousDateStr = date.toISOString().split('T')[0];
      // console.log("Date in all ",previousDateStr)
      const params = new HttpParams()
      .set('orderBy', '"departureDate"')
      .set('startAt', "${previousDateStr}");
      return  this.http.get<any>(`${this.apiUrl}/driverRideData/${userID}.json`,
      {params:new HttpParams()
        .set('orderBy', '"departureDate"')
      .set('startAt', `"${previousDateStr}"`
      )})
    }
    else if(text==='past'){    
      console.log("past Called")
    // Subtract one day from the date
    const today = new Date();
    const date = new Date();
    date.setDate(today.getDate() - 1);
    // Format the date back to YYYY-MM-DD string
    const previousDateStr = date.toISOString().split('T')[0];
    //convert ends
    const params = new HttpParams()
      .set('orderBy', '"departureDate"')
      .set('endAt', "${previousDateStr}");
      return  this.http.get<any>(`${this.apiUrl}/driverRideData/${userID}.json`,{params: new HttpParams()
        .set('orderBy', '"departureDate"')
        .set('endAt', `"${previousDateStr}"`)})
    }
    else{}
 return null
  }
}