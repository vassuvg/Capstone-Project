import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { catchError, map, switchMap } from 'rxjs/operators';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {
  private apiUrl = 'https://driveshare-c4036-default-rtdb.firebaseio.com';

  constructor(private http: HttpClient) {}

  getProfile(userId: string) {
    return this.http.get<{ [key: string]: any }>(`${this.apiUrl}/profiles/${userId}.json`)
      .pipe(
        map(responseData => {
          const profilesArray = [];
          for (const key in responseData) {
            if (responseData.hasOwnProperty(key)) {
              profilesArray.push({ ...responseData[key], id: key, userId });
            }
          }
          return profilesArray.length > 0 ? profilesArray[0] : null;
        })
      );
  }

  getProfileName(): Observable<string> {     
    return this.http.get<string>(`https://driveshare-c4036-default-rtdb.firebaseio.com/profiles.json`); 
    
  }

  getPassengerData(userId: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/profiles/${userId}.json`).pipe(
      catchError(error => {
        console.error('Error fetching data for userId:', userId, error);
        return of(null); // Return null if there's an error
      })
    );
  }
}
