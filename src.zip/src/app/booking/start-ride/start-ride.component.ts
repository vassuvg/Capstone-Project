import { Component, ElementRef, OnInit, ViewChild, AfterViewInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AlertController, NavController, ToastController } from '@ionic/angular';
import { Geolocation } from '@capacitor/geolocation';

declare var google;

@Component({
  selector: 'app-start-ride',
  templateUrl: './start-ride.component.html',
  styleUrls: ['./start-ride.component.scss'],
})
export class StartRideComponent implements OnInit, AfterViewInit, OnDestroy {

  @ViewChild('mapElement', { static: true }) mapElement: ElementRef;
  map: any;
  directionsService = new google.maps.DirectionsService();
  directionsRendererPassenger = new google.maps.DirectionsRenderer();

  driverPickupLocation: string;
  driverDropoffLocation: string;
  passengerPickupLocation: string;
  passengerDropoffLocation: string;

  driverMarker: any;
  passengerPickupLatLng: any;
  cabPath: any; // To hold the polyline
  watchId: string;
  private hasShownMeetupToast: boolean = false;

  supportsAnimationFrame: boolean = 'requestAnimationFrame' in window;
  animationFrameId: number = null;
  intervalId: number = null;

  constructor(
    private route: ActivatedRoute,
    private navCtrl: NavController,
    private toastController: ToastController,
  ) {}

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.driverPickupLocation = params['driverPickup'];
      this.driverDropoffLocation = params['driverDropoff'];
      this.passengerPickupLocation = params['pickup'];
      this.passengerDropoffLocation = params['dropoff'];
    });
  }

  ngAfterViewInit() {
    this.loadMapWithDirection();
    this.trackDriverLocation();
  }

  async presentToast(message: string) {
    const toast = await this.toastController.create({
      message: message,
      duration: 3000, // Duration for 3 seconds
      position: 'bottom', // Position at the bottom of the screen
    });
    await toast.present();
  }

  loadMapWithDirection() {
    this.map = new google.maps.Map(this.mapElement.nativeElement, {
      zoom: 10,
      center: { lat: 43.731548, lng: -79.762421 },
    });

    this.directionsRendererPassenger = new google.maps.DirectionsRenderer({
      suppressMarkers: true,
      polylineOptions: {
        strokeColor: 'blue',
      },
    });
    this.directionsRendererPassenger.setMap(this.map);

    this.calculateAndDisplayRoute();
  }

  calculateAndDisplayRoute() {
    this.directionsService
      .route({
        origin: { query: this.passengerPickupLocation },
        destination: { query: this.passengerDropoffLocation },
        travelMode: google.maps.TravelMode.DRIVING,
      })
      .then((response) => {
        if (response && response.status === 'OK') {
          this.directionsRendererPassenger.setDirections(response);

          const passengerPickupLocation = response.routes[0].legs[0].start_location;
          const passengerDropoffLocation = response.routes[0].legs[0].end_location;

          this.passengerPickupLatLng = passengerPickupLocation;

          new google.maps.Marker({
            map: this.map,
            position: passengerPickupLocation,
            label: 'PL',
            title: 'Passenger Pickup Location',
          });

          new google.maps.Marker({
            map: this.map,
            position: passengerDropoffLocation,
            label: 'DL',
            title: 'Passenger Dropoff Location',
          });
        } else {
          console.error('Passenger directions request failed due to ' + response.status);
        }
      })
      .catch((e) => console.error('Passenger directions request failed due to ' + e));
  }
  async trackDriverLocation() {
    const watchOptions = {
      enableHighAccuracy: true,
      timeout: 10000,
      maximumAge: 0,
    };
  
    let lastPosition = null;
  
    const updateDriverLocation = async () => {
      const position = await Geolocation.getCurrentPosition(watchOptions);
      const lat = position.coords.latitude;
      const lng = position.coords.longitude;
      const latLng = new google.maps.LatLng(lat, lng);
  
      if (this.driverMarker) {
        this.driverMarker.setPosition(latLng); // Update the marker's position
  
        if (lastPosition) {
          const bearing = google.maps.geometry.spherical.computeHeading(
            lastPosition,
            latLng
          );
  
          // Update the map's heading and tilt
          this.map.setHeading(bearing); // Align map with the direction
          this.map.setTilt(45); // Tilt map for better view (Optional)
  
          this.map.panTo(latLng); // Center the map on the new position
        }
  
        lastPosition = latLng; // Save the current position for the next calculation
      } else {
        this.driverMarker = new google.maps.Marker({
          map: this.map,
          position: latLng,
          icon: {
            url: 'assets/cars.png', // Replace with your car icon path
            scaledSize: new google.maps.Size(50, 50),
          },
        });
  
        this.map.panTo(latLng); // Center the map on the new position
      }
  
      if (this.passengerPickupLatLng) {
        this.directionsService
          .route({
            origin: latLng,
            destination: this.passengerPickupLatLng,
            travelMode: google.maps.TravelMode.DRIVING,
          })
          .then((response) => {
            if (response && response.status === 'OK') {
              const path = response.routes[0].overview_path;
  
              if (this.cabPath) {
                this.cabPath.setPath(path); // Update the polyline's path with the full route
              } else {
                this.cabPath = new google.maps.Polyline({
                  path: path,
                  geodesic: true,
                  strokeColor: 'red',
                  strokeOpacity: 1.0,
                  strokeWeight: 5,
                });
                this.cabPath.setMap(this.map);
              }
            } else {
              console.error('Polyline directions request failed due to ' + response.status);
            }
          })
          .catch((e) => console.error('Polyline directions request failed due to ' + e));
  
        const distanceToPickup = google.maps.geometry.spherical.computeDistanceBetween(
          latLng,
          this.passengerPickupLatLng
        );
        if (distanceToPickup < 10 && !this.hasShownMeetupToast) {
          this.presentToast('Meetup done with Passenger, starting ride now!');
          this.hasShownMeetupToast = true; // Set flag to true after showing toast
        }
      }
  
      const passengerDropoffLatLng = new google.maps.LatLng(
        this.passengerDropoffLocation
      );
      const distanceToDropoff = google.maps.geometry.spherical.computeDistanceBetween(
        latLng,
        passengerDropoffLatLng
      );
  
      if (distanceToDropoff < 10 && !this.hasShownMeetupToast) {
        this.presentToast('Ride completed!');
        this.hasShownMeetupToast = true; // Ensure the toast is shown only once
      }
    };
  
    this.intervalId = setInterval(updateDriverLocation, 1000) as unknown as number; // Update every second
  }
  
  
  clearAnimationIntervals() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
    }
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
    if (this.cabPath) {
      this.cabPath.setMap(null); // Remove the polyline from the map
      this.cabPath = null;
    }
  }

  ngOnDestroy() {
    if (this.watchId) {
      Geolocation.clearWatch({ id: this.watchId });
    }
    this.clearAnimationIntervals();
  }
}
