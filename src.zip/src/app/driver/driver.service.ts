import { Injectable } from '@angular/core';
import { forkJoin } from 'rxjs';
import { DriverInfoService } from '../driver-rideinfo/driver-rideinfo.service';
import { ProfileService } from '../profile/profile.service';

@Injectable({
  providedIn: 'root',
})
export class DriverService {
  availableRoutes: any[] = [];
  userNames: string[] = [];
  userImages: string[] = [];
  DriverRiderID: string[] = [];
  userId: string[] = [];
  gender: string[] = [];
  //departureDates: Set<string> = new Set();
  departureDates: string [] = [];
  

  constructor(
    private driverInfoService: DriverInfoService,
    private profileService: ProfileService
  ) {
    this.initializeRoutes();
  }

  initializeRoutes() {
    forkJoin({
      pickupLocation: this.driverInfoService.getDriverRideId(),
      dropoffLocation: this.driverInfoService.getDropoffLocation(),
      departureDate: this.driverInfoService.getDropoffLocation(),
      userName: this.profileService.getProfileName(),
      userImage: this.profileService.getProfileName(),
      gender: this.profileService.getProfileName(),
      driveUserId: this.profileService.getProfileName(),
      DriverRiderID: this.driverInfoService.getDriverRideId(),
    }).subscribe(
      ({
        pickupLocation,
        dropoffLocation,
        userName,
        userImage,
        driveUserId,
        gender,
        departureDate,
        DriverRiderID,
      }) => {
        this.availableRoutes = Object.keys(driveUserId).reduce((acc, key) => {
          if (pickupLocation[key] && dropoffLocation[key]) {
            const driverRideIds = Object.keys(DriverRiderID[key]);
            driverRideIds.forEach((rideKey) => {
              const ride = DriverRiderID[key][rideKey];
            acc.push({
              origin: ride.pickupLocation,
              destination: ride.dropoffLocation,
              travelMode: 'DRIVING'
            });
            //this.DriverRiderID.push((Object.keys(DriverRiderID[key])[0] as string) ),
           // this.userNames.push((Object.values(userName[key])[0] as any).fullName);
            //this.userImages.push((Object.values(userImage[key])[0] as any).user_image);
            //this.userId.push((Object.values(driveUserId[key])[0] as any).userId);
            //this.departureDate.push((Object.values(departureDate[key])[0] as any).departureDate);
          

        //  const driverRideIds2 = Object.keys(DriverRiderID[key]);
         // driverRideIds2.forEach((rideKey) => {
           // const ride = DriverRiderID[key][rideKey];
        //});


        this.departureDates.push(ride.departureDate);
        this.userNames.push((Object.values(userName[key])[0] as any).fullName);
        this.gender.push((Object.values(gender[key])[0] as any).gender);
        this.userImages.push((Object.values(userImage[key])[0] as any).user_image);
        this.userId.push(ride.userId);
        this.DriverRiderID.push(rideKey);
          });

 

          
          

           // const driverRideIds = Object.keys(DriverRiderID[key]);
           // driverRideIds.forEach((rideKey) => {
            //  const ride = DriverRiderID[key][rideKey];
             
            //  this.departureDates.add(ride.departureDate); // Add departure date to the set
             // const userNameValue = (Object.values(userName[key])[0] as any).fullName;
              //this.userNames.push(userNameValue); 

             /* const routeIndex = this.userNames.length - 1;
              acc.push({
                origin: ride.pickupLocation,
                destination: ride.dropoffLocation,
                travelMode: 'DRIVING',
                driverRiderID: rideKey,
                userName: this.userNames[routeIndex],
                userImage: (Object.values(userImage[key])[0] as any).user_image,
                userId: (Object.values(driveUserId[key])[0] as any).userId,
                departureDates: ride.departureDate
              });*/

            

              // Assign properties outside acc.push
             

              
          

          //  this.DriverRiderID.push((Object.keys(DriverRiderID[key])[0] as string) ),
            //this.userNames.push((Object.values(userName[key])[0] as any).fullName);
            //this.userImages.push((Object.values(userImage[key])[0] as any).user_image);
            //this.userId.push((Object.values(driveUserId[key])[0] as any).userId);
            //this.departureDates.push((Object.values(departureDate[key])[0] as any).departureDate);
             
           
           // });
          }
          return acc;
        }, []);

        console.log("Available Routes:", this.availableRoutes);
        console.log("Driver Names:", this.userNames);
        console.log("Driver departure date:", this.departureDates);
        console.log("Driver User ID:", this.userId);
        //console.log("Driver User Image:", this.userImages);
        console.log("Driver Rider ID:", this.DriverRiderID);


      },
      (error) => {
        console.error('Error loading routes', error);
      }
    );
  }
}


/*import { Injectable } from '@angular/core';
import { forkJoin } from 'rxjs';
import { DriverInfoService } from '../driver-rideinfo/driver-rideinfo.service';
import { ProfileService } from '../profile/profile.service';

@Injectable({
  providedIn: 'root',
})
export class DriverService {
  availableRoutes: any[] = [];
  additionalData: any[] = [] // Flattened data storage

  constructor(
    private driverInfoService: DriverInfoService,
    private profileService: ProfileService
  ) {
    this.initializeRoutes();
  }

  initializeRoutes() {
    forkJoin({
      pickupLocation: this.driverInfoService.getDriverRideId(),
      dropoffLocation: this.driverInfoService.getDropoffLocation(),
      departureDate: this.driverInfoService.getDropoffLocation(),
      userName: this.profileService.getProfileName(),
      userImage: this.profileService.getProfileName(),
      driveUserId: this.profileService.getProfileName(),
      driverRiderID: this.driverInfoService.getDriverRideId(),
    }).subscribe(
      ({
        pickupLocation,
        dropoffLocation,
        userName,
        userImage,
        driveUserId,
        departureDate,
        driverRiderID,
      }) => {
        this.availableRoutes = Object.keys(driverRiderID).reduce((acc, key) => {
          if (pickupLocation[key] && dropoffLocation[key]) {
            const driverRideIds = Object.keys(driverRiderID[key]);
            driverRideIds.forEach((rideKey) => {
              const ride = driverRiderID[key][rideKey];
             
              const route = {
                origin: ride.pickupLocation,
                destination: ride.dropoffLocation,
                travelMode: 'DRIVING',
               // driverRiderID: rideKey // Include driverRiderID for reference
              };

              // Flatten the additional data
              this.additionalData[rideKey] = {
                userName: (Object.values(userName[key])[0] as any).fullName,
                userImage: (Object.values(userImage[key])[0] as any).user_image,
                userId: (Object.values(driveUserId[key])[0] as any).userId,
                departureDate: ride.departureDate,
                
              };

              acc.push(route);
            });
          }
          return acc;
        }, []);

        console.log("Available Routes:", this.availableRoutes);
        console.log("Additional Data:", this.additionalData);
      },
      (error) => {
        console.error('Error loading routes', error);
      }
    );
  }
}

*/