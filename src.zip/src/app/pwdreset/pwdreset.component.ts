import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { LoadingController, AlertController } from '@ionic/angular';
import { getAuth, sendPasswordResetEmail } from 'firebase/auth';

@Component({
  selector: 'app-pwdreset',
  templateUrl: './pwdreset.component.html',
  styleUrls: ['./pwdreset.component.scss'],
})
export class PwdresetComponent implements OnInit {
  isLoading = false;

  constructor(
    private router: Router,
    private loadingCtrl: LoadingController,
    private alertCtrl: AlertController
  ) {}

  ngOnInit(): void {}

  onSubmit(form: NgForm) {
    if (!form.valid) {
      return;
    }
    const email = form.value.email;
    this.isLoading = true;
    this.loadingCtrl
      .create({ keyboardClose: true, message: 'Sending password reset email...' })
      .then((loadingEl) => {
        loadingEl.present();
        const auth = getAuth();
        sendPasswordResetEmail(auth, email).then(
          () => {
            loadingEl.dismiss();
            this.isLoading = false;
            this.showAlert('Password reset email sent successfully. Please check your inbox.');
            form.reset();
            this.router.navigate(['/auth']);
          },
          (error) => {
            loadingEl.dismiss();
            this.isLoading = false;
            let message = 'Sending password reset email failed.';
            if (error.code === 'auth/user-not-found') {
              message = 'This email address could not be found.';
            }
            this.showAlert(message);
          }
        );
      });
  }

  private showAlert(message: string) {
    this.alertCtrl
      .create({
        header: 'Reset Password',
        message: message,
        buttons: ['Okay']
      })
      .then(alertEl => alertEl.present());
  }
}
