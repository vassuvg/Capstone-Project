import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class DriverRideDataService {
  private apiUrl = 'https://driveshare-c4036-default-rtdb.firebaseio.com/driverRideData.json';

  constructor(private http: HttpClient) {}

  // Method to fetch all ride data from the database
  getRideData(): Observable<any[]> {
    return this.http.get<{ [key: string]: any }>(this.apiUrl)
      .pipe(
        map(data => {
          if (data) {
            return Object.entries(data).map(([key, value]) => ({ [key]: value })); // Convert to array of objects with key
          } else {
            throw new Error('No data found from the API');
          }
        })
      );
  }
}

