import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DriverRideData } from './driver-ridedata.model';
import { Router } from '@angular/router';
import { ActionSheetController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { AuthService } from '../auth/auth.service';
import { take } from 'rxjs';
import { DriverInfoService } from '../driver-rideinfo/driver-rideinfo.service';

@Component({
  selector: 'app-driver-ridedata',
  templateUrl: './driver-ridedata.component.html',
  styleUrls: ['./driver-ridedata.component.scss'],
})
export class DriverRidedataComponent implements OnInit {
  driverDetailForm: FormGroup;
  driverRideData: DriverRideData = new DriverRideData(); // Initialize with model object
  userId: string;
  pickupQuery: string;
  dropoffQuery: string;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    public actionSheetController: ActionSheetController,
    private http: HttpClient,
    private authService: AuthService,private driverinfoservice: DriverInfoService
  ) { }

  ngOnInit(): void {
    // Get userId from AuthService
    this.authService.userId.pipe(take(1)).subscribe(userId => {
      this.userId = userId;
      console.log('User ID:', this.userId);  // Log user ID for debugging
      this.initializeForm();

      this.driverinfoservice.getPickupQuery().pipe(take(1)).subscribe(pickupQuery => {
        this.pickupQuery = pickupQuery;
        console.log('Pickup Query:', this.pickupQuery);
      });
      
      this.driverinfoservice.getDropoffQuery().pipe(take(1)).subscribe(dropoffQuery => {
        this.dropoffQuery = dropoffQuery;
        console.log('Dropoff Query:', this.dropoffQuery);
      });
             console.log('Pickup Query:', this.pickupQuery);
             console.log('Dropoff Query:', this.dropoffQuery);
          });
    
  }

  initializeForm() {
    // Initialize the form group with default values or empty values
    this.driverDetailForm = this.fb.group({
      departureDate: [null, Validators.required],
      departureTime: [null, Validators.required],
      seats: [null, [Validators.required, Validators.min(1), Validators.max(3)]],
      luggage: [null, [Validators.required, Validators.min(0), Validators.max(3)]],
      additionalDetails: [null , Validators.required]
    });
  }

  // Convenience getter for easy access to form fields
  get f() { return this.driverDetailForm.controls; }

  onSubmit() {
    // Stop here if form is invalid
    if (this.driverDetailForm.invalid) {
      return;
    }

    // Assign form values to the passenger detail object
    this.driverRideData.departureDate = this.driverDetailForm.value.departureDate;
    this.driverRideData.departureTime = this.driverDetailForm.value.departureTime;
    this.driverRideData.seats = this.driverDetailForm.value.seats;
    this.driverRideData.luggage = this.driverDetailForm.value.luggage;
    this.driverRideData.additionalDetails = this.driverDetailForm.value.additionalDetails;


    this.driverRideData.pickupLocation = this.pickupQuery;
    this.driverRideData.dropoffLocation = this.dropoffQuery;

    // Ensure userId is set
    if (this.userId) {
      this.driverRideData.userId = this.userId;

      // Make an HTTP POST request to save passenger detail data
      this.http.post(`https://driveshare-c4036-default-rtdb.firebaseio.com/driverRideData/${this.userId}.json`, this.driverRideData)
        .subscribe(
          (response: any) => {
            // Handle success
            console.log('POST request successful:', response);
            this.driverinfoservice.setDriverState({
              departureDate: this.driverRideData.departureDate,
              departureTime: this.driverRideData.departureTime,
              seats: this.driverRideData.seats,
              luggage: this.driverRideData.luggage,
              additionalDetails: this.driverRideData.additionalDetails,
              pickupLocation: this.driverRideData.pickupLocation,
              dropoffLocation: this.driverRideData.dropoffLocation
            });
            this.presentActionSheet();
          },
          (error) => {
            // Handle error
            console.error('Error making POST request:', error);
          }
        );

      // Reset the form
      this.driverDetailForm.reset();
    } else {
      console.error('User ID is not available');
    }
  }

  async presentActionSheet() {
    const actionSheet = await this.actionSheetController.create({
      header: 'Ride posted',
      buttons: [
        {
          text: 'OK',
          handler: () => {
            this.router.navigate(['/driver']); // Navigate back to passenger page
          }
        },
        {
          text: 'View Ride Details',
          handler: async () => {
            // Fetch data from the provided URLs
            try {
            
              this.router.navigate(['/viewride-driverdetail']);
            } catch (error) {
              console.error('Error fetching data:', error);
              // Handle error
              const alert = await this.actionSheetController.create({
                header: 'Error',
                buttons: ['OK']
              });
              await alert.present();
            }
          }
        }
      ]
    });
    await actionSheet.present();
  }
}
