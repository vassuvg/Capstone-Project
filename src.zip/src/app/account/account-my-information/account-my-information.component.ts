import { DOCUMENT } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Platform } from '@ionic/angular';
import { AuthService } from 'src/app/auth/auth.service';
import { Account, UpdateInfo } from '../account.model';
import { Subscription, take } from 'rxjs';
import { AccountService } from '../account.service';
import { Camera, CameraResultType, CameraSource, Photo } from '@capacitor/camera';
import { Filesystem, Directory } from '@capacitor/filesystem';
 
@Component({
  selector: 'app-account-my-information',
  templateUrl: './account-my-information.component.html',
  styleUrls: ['./account-my-information.component.scss'],
})
export class AccountMyInformationComponent implements OnInit {
 
 
  public Name:string;
  public Gender:string;
  inputName: string = '';
 
  private authSub: Subscription;
  private previousAuthState = false;
  userId: string='';
  emailId:string='';
  selectedImage:string='';
  private allAccount: any='';
  private filteredAccounts;
  myAccount: Account = {
    Tableid:null,
    fullName: null,
    phoneNumber: '',
    gender: '',
    userId:'',
    selectedImage:''
  };
  UpdateAccountInfo: UpdateInfo = {
    fullName: '',
    gender: '',
    user_image:''
  };
 
 
 
 
  constructor(private authService: AuthService, private router: Router, private AccountService:AccountService  , private platform: Platform,  private http: HttpClient,@Inject(DOCUMENT) private document: Document
  ) { }
 
  ngOnInit() {
    this.authSub = this.authService.userIsAuthenticated.subscribe(isAuth => {
      if (!isAuth && this.previousAuthState !== isAuth) {
        this.router.navigateByUrl('/auth');
      }
      this.previousAuthState = isAuth;
    });
 
      this.authService.userId.pipe(take(1)).subscribe(userId => {
        this.userId = userId;
        console.log('User ID:', this.userId);  // Log user ID for debugging
      //  this.initializeForm();
      });
 
      this.authService.emailId.pipe(
        take(1)
      ).subscribe(emailId => {
        this.emailId = emailId;
        console.log('Email ID:', emailId);
      });
      //const data=`https://driveshare-c4036-default-rtdb.firebaseio.com/profiles.json`
     // console.log('profiles',data);
     this.GetFilteredAccount();
    }
  async GetFilteredAccount(){
    this.http.get<Account>(`https://driveshare-c4036-default-rtdb.firebaseio.com/profiles/${this.userId}.json`)
     .subscribe(account => {
 
       if (account) {
         console.log("accounts:",account)
         this.allAccount=account;
         
         const dataArray = Object.keys(this.allAccount).map(key => ({
          Tableid: key,
          ...this.allAccount[key]
        }));
       
        console.log('dayaarray',dataArray);
 
         console.log("Allaccouts",this.allAccount);
        //  this.filteredAccounts = Object.keys(this.allAccount).filter((account: any) => {
        //   return account.userId === this.userId;
        //    // Example filter by gender
        // });
        this.filteredAccounts = dataArray.find(x => x.userId === this.userId);
        console.log("filteredAccounts",this.filteredAccounts);
         this.myAccount.Tableid = this.filteredAccounts.Tableid;
         this.myAccount.fullName=this.filteredAccounts.fullName;
        this.myAccount.phoneNumber=this.filteredAccounts.phoneNumber
        this.myAccount.gender=this.filteredAccounts.gender
        this.myAccount.userId=this.filteredAccounts.userId // use the userId from ngoninit using auth service
        this.myAccount.selectedImage=this.filteredAccounts.user_image
        console.log("myAccount",this.myAccount)
       
       
        //try with model
         } else {
       }
     });
  }
 
 
 
  logout() {
    this.authService.logout();
console.log(this.myAccount)
// this.document.location.reload();
 
  }
  onSave(){
    console.log("onSave")
    console.log("my account:",this.myAccount)
    this.UpdateAccountInfo.fullName=this.myAccount.fullName
    this.UpdateAccountInfo.gender=this.myAccount.gender
    this.UpdateAccountInfo.user_image=this.myAccount.selectedImage
    console.log("UpdatedInfo",this.UpdateAccountInfo)
 
    //this service takes tableid and the updates fields as its parameters
     this.AccountService.updateAccountFields(this.myAccount.userId,this.myAccount.Tableid, this.UpdateAccountInfo).subscribe(() => {
       console.log('Account fields updated');
       console.log(this.UpdateAccountInfo.user_image)
     });
   
  }
//to select image from gallery/from device
  async selectImage() {
    if (this.platform.is('capacitor') || this.platform.is('hybrid') || this.platform.is('desktop')|| this.platform.is('mobileweb') || this.platform.is('iphone') || this.platform.is('ios')) {
      console.log(this.platform)
      try {
        const image = await Camera.getPhoto({
          quality: 90,
          allowEditing: false,
          resultType: CameraResultType.DataUrl,
          source: CameraSource.Prompt,
        });
       
//resize image is user defined function
        this.resizeImage(image.dataUrl, 500, 500).then(resizedImage => {
          this.selectedImage = resizedImage;
          console.log('SelectedImage',this.selectedImage)
          this.myAccount.selectedImage=this.selectedImage
         // this.profileForm.patchValue({ user_image: this.selectedImage });
        });
 
      } catch (error) {
        console.error('Error capturing image:', error);
      }
    } else {
      console.log('else called',this.platform)
      this.selectImageWeb();
     
    }
  }
//To click a picture using camera
  async takePicture() {
    if (this.platform.is('capacitor') || this.platform.is('hybrid') || this.platform.is('desktop') || this.platform.is('mobileweb') || this.platform.is('iphone') || this.platform.is('ios')) {
      try {
        const image = await Camera.getPhoto({
          quality: 90,
          allowEditing: false,
          resultType: CameraResultType.DataUrl,
          source: CameraSource.Camera, // This will directly open the camera
        });
//resize image is a userr defined function
        this.resizeImage(image.dataUrl, 500, 500).then(resizedImage => {
          this.selectedImage = resizedImage;
          console.log('SelectedImage',this.selectedImage);
          this.myAccount.selectedImage=this.selectedImage
 
          // this.profileForm.patchValue({ user_image: this.selectedImage });
        });
 
      } catch (error) {
        console.error('Error capturing image:', error);
      }
    } else {
      console.error('Camera is not available on this platform');
    }
  }
 
 
  selectImageWeb() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (event: any) => {
      const file = event.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          const imageDataUrl = e.target.result as string;
          this.resizeImage(imageDataUrl, 500, 500).then(resizedImage => {
            this.selectedImage = resizedImage;
           // this.profileForm.patchValue({ user_image: this.selectedImage });
           console.log("SelectedImage",this.selectedImage)
          });
        };
        reader.readAsDataURL(file);
      }
    };
    input.click();
  }
 
  resizeImage(dataUrl: string, maxWidth: number, maxHeight: number): Promise<string> {
    return new Promise((resolve) => {
      const img = new Image();
      img.src = dataUrl;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;
 
        if (width > maxWidth) {
          height *= maxWidth / width;
          width = maxWidth;
        }
        if (height > maxHeight) {
          width *= maxHeight / height;
          height = maxHeight;
        }
 
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);
 
        resolve(canvas.toDataURL('image/jpeg', 0.8));
      };
    });
  }
  DeleteAccount(){
    if (this.userId) {
      console.log("Delete ended",this.userId)
      // const user = ;
 
      //this.AccountService.deleteAccount(this.userId);
 
      // user.delete().then(() => {
      //   console.log('User deleted from Firebase Authentication');
      //   // Optionally delete associated user data
      //   // this.accountService.deleteAccount(this.accountId).subscribe(() => {
      //   //   console.log('User data deleted from Realtime Database');
      //   //   // Navigate to the login or home page
      //   //   this.router.navigateByUrl('/auth');
      //   // });
      // }).catch(error => {
      //   console.error('Error deleting user:', error);
      // });
    } else {
      console.error('No user is currently signed in.');
    }
  }
 
 
 
  OnDestroy(): void {
    if (this.authSub) {
      this.authSub.unsubscribe();
    }
  }
 
}
 