import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoadingController } from '@ionic/angular';

@Component({
  selector: 'app-driver-home',
  templateUrl: './driver-home.component.html',
  styleUrls: ['./driver-home.component.scss'],
})
export class DriverHomeComponent implements OnInit {

  constructor(
    private router: Router,
    private loadingController: LoadingController
  ) {}

  ngOnInit() {}

  async presentLoading() {
    const loading = await this.loadingController.create({
      message: 'Please wait...',
      duration: 2000,  // You can adjust this duration or remove it to keep it until manually dismissed
    });
    await loading.present();
    return loading;
  }

  async postRide() {
    const loading = await this.presentLoading();
    this.router.navigate(['/driver-rideinfo']).then(() => {
      loading.dismiss();
    });
  }

  async viewPendingRideRequests() {
    const loading = await this.presentLoading();
    this.router.navigate(['/passenger-rides-request']).then(() => {
      loading.dismiss();
    });
  }

  async checkMyRides() {
    const loading = await this.presentLoading();
    this.router.navigate(['/driver-myride']).then(() => {
      loading.dismiss();
    });
  }

  async bookedRides() {
    const loading = await this.presentLoading();
    this.router.navigate(['/booking']).then(() => {
      loading.dismiss();
    });
  }
}
