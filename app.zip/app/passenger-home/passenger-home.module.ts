import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { RouterModule } from '@angular/router';
import { PassengerHomeComponent } from './passenger-home.component';


@NgModule({
  declarations: [PassengerHomeComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    IonicModule,
    RouterModule.forChild([
      {
        path: '',
        component: PassengerHomeComponent
      }
    ])
  ],
})
export class PassengerHomeModule {}