import { HttpClient } from '@angular/common/http';
import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { AlertController, LoadingController } from '@ionic/angular';
import { Subscription, take } from 'rxjs';
import { AuthService } from '../auth/auth.service';
import { Router } from '@angular/router';
import { PassengerService } from '../passenger/passenger.service';


export const PATH_ELIGIBILITY_OFFSET = 5;

export type LatLng = { lat: number, lng: number };
declare var google;

@Component({
  selector: 'app-viewdriver-rideinfo',
  templateUrl: './viewdriver-rideinfo.component.html',
  styleUrls: ['./viewdriver-rideinfo.component.scss'],
})
export class ViewdriverRideinfoComponent implements OnInit, OnDestroy {
  pickupQuery: string;
  dropoffQuery: string;
  driverDetail: any; // Ensure passengerDetail is defined
  destinationOffsetStep = 0;
  eligiblePassengers: {passengerRideId: string,image : string, name: string; origin: string; destination: string, passengerUserId: string }[] = [];
  userId : string;
  //pickupLocations: any[] = [];
  pickupLocation: any;
  dropoffLocation: any

  @ViewChild('mapElement', {static: false}) mapElement;
  directionsService = new google.maps.DirectionsService();
  directionsRenderer = new google.maps.DirectionsRenderer();

  private authSub: Subscription;
  departureDate: any;
  seats: any;
  luggage: any;
  departureTime: any;
  additionalDetails: any;
   constructor(
    private loadingController : LoadingController,
    private alertController: AlertController,
    private http: HttpClient,
    private authService: AuthService, 
    private router: Router,
    private passengerService : PassengerService
  ) { }

  ngOnInit(): void {
    // Fetch userId from AuthService

    this.authSub = this.authService.userIsAuthenticated.subscribe(isAuth => {
      if (!isAuth) {
        this.resetForm();
      } else {
        // User is authenticated, initialize data
        this.initializeData();
      }
    });
    this.authService.userId.pipe(take(1)).subscribe(userId => {
      this.userId = userId;
      this.initializeData(); // Call method to initialize data
    });
  }



  ngOnDestroy(): void {
    if (this.authSub) {
      this.authSub.unsubscribe();
    }
  }
  // Method to initialize data
  initializeData() {
    console.log('User ID:', this.userId); // Log user ID
    
 

    
   // Fetch passenger details using HttpClient
  this.http
  .get<any>(`https://driveshare-c4036-default-rtdb.firebaseio.com/driverRideData/${this.userId}.json`)
  .subscribe(
    (passengerDetailResponse: any) => {
      console.log('Driver Details:', passengerDetailResponse); // Log passenger details
      //this.passengerDetail = passengerDetailResponse;
      
      if(passengerDetailResponse){
       // let mostRecentPassengerDetails: any = null;
      // Example of accessing additional fields like 'no', 'departureDate', etc.
      let mostRecentPassengerDetails = Object.values(passengerDetailResponse)
            .find((passenger: any) => passenger.userId === this.userId);
      for (const key in passengerDetailResponse) {
        if (passengerDetailResponse.hasOwnProperty(key)) {
          const passenger = passengerDetailResponse[key];
          console.log('Driver:', passenger);

          if(passenger.userId === this.userId){
            mostRecentPassengerDetails = passenger
          }

        }
      }
      if(mostRecentPassengerDetails){
      this.departureDate = mostRecentPassengerDetails;
      this.seats = mostRecentPassengerDetails;
      this.luggage = mostRecentPassengerDetails;
      this.departureTime = mostRecentPassengerDetails;
      this.additionalDetails = mostRecentPassengerDetails;
      this.pickupLocation = mostRecentPassengerDetails;
      this.dropoffLocation = mostRecentPassengerDetails;
      }}
    },
    (error) => {
      console.error('Error fetching passenger details:', error);
    }
  );
 // Fetch pickup locations using HttpClient
 /*this.http
 .get<any>(`https://driveshare-c4036-default-rtdb.firebaseio.com/driverpickupLocations/${this.userId}.json`)
 .subscribe(
   (pickupLocationsResponse: any) => {
     console.log('Pickup Locations:', pickupLocationsResponse); // Log pickup locations

     // Handle pickup locations response
     if (pickupLocationsResponse) {
       let mostRecentPickupLocation: any = null;

       // Iterate over each pickup location
       for (const key in pickupLocationsResponse) {
         if (pickupLocationsResponse.hasOwnProperty(key)) {
           const pickupLocation = pickupLocationsResponse[key];
           console.log('Pickup Location:', pickupLocation);

           // Check if the pickup location belongs to the current user
           if (pickupLocation.userId === this.userId) {
             // Update the most recent pickup location
             mostRecentPickupLocation = pickupLocation;
           }
         }
       }

       // Assign the most recent pickup location to pickupLocation property
       this.pickupLocation = mostRecentPickupLocation;
     } else {
       console.error('No pickup locations found for user:', this.userId);
     }
   },
   (error) => {
     console.error('Error fetching pickup locations:', error);
   }
 );
  
    // Fetch dropoff locations using HttpClient
    this.http
      .get<any>(`https://driveshare-c4036-default-rtdb.firebaseio.com/driverdropoffLocations/${this.userId}.json`)
      .subscribe(
        (dropoffLocationsResponse: any) => {
          console.log('Dropoff Locations:', dropoffLocationsResponse); // Log dropoff locations
          // Handle dropoff locations response
          if(dropoffLocationsResponse){
            let mostRecentDropoffLocation: any = null;

            //iterate over each drop off location
            for(const key in dropoffLocationsResponse){
              if(dropoffLocationsResponse.hasOwnProperty(key)){
              const dropoffLocation = dropoffLocationsResponse[key];
              console.log('Dropoff Location', dropoffLocation);

              if(dropoffLocation.userId === this.userId){
                mostRecentDropoffLocation = dropoffLocation;
              }
              }
            }
            this.dropoffLocation = mostRecentDropoffLocation;
          } else {
            console.error('no dropoff location found for user', this.userId)
          }
        },
        (error) => {
          console.error('Error fetching dropoff locations:', error);
        }
      );*/
  }
  

  /*ngOnInit(): void {
    this.pickupQuery = this.passengerService.getPickupQuery();
    this.dropoffQuery = this.passengerService.getDropoffQuery();
    
    // Fetch passenger details using HttpClient
    this.http.get<any>('https://driveshare-c4036-default-rtdb.firebaseio.com/passengerDetails.json')
      .subscribe((passengerDetailResponse: any) => {
        this.passengerDetail = passengerDetailResponse;
      }, (error) => {
        console.error('Error fetching passenger details:', error);
      });
  }
  */
 /* async onViewMatches() {
    this.eligibleDrivers = [];
    const routes = this.driverService.availableRoutes;
    await Promise.all(routes.map(route => this.getEligibleRoutes(route)));
  }*/




  async onViewMatches() {
    // Show loading indicator while fetching matches
    const loading = await this.loadingController.create({
      message: 'Loading...',
      translucent: true,
      spinner: 'bubbles'
    });
    await loading.present();
  
    this.eligiblePassengers = [];
    //const routes = this.driverService.availableRoutes;
    //const routes = this.passengerService.availableRoutes;


    const routes = this.passengerService.availableRoutes;
      console.log(routes)
      for (const route of routes) {
        await this.getEligibleRoutes(route);
        //console.log(await this.getEligibleRoutes(route))
      }
  
    try {
      await Promise.all(routes.map(route => this.getEligibleRoutes(route)));
    } catch (error) {
      console.error('Error fetching eligible routes:', error);
      // Handle error - show alert
      const alert = await this.alertController.create({
        header: 'Error',
        message: 'Failed to fetch eligible routes. Please try again later.',
        buttons: ['OK']
      });
      await alert.present();
    } finally {
      // Dismiss loading indicator
      await loading.dismiss();
      // If no matching drivers found, show alert
      if (this.eligiblePassengers.length === 0) {
        const alert = await this.alertController.create({
          header: 'No Matches',
          message: 'No matching drivers found.',
          buttons: ['OK']
        });
        await alert.present();
      }
    }
  }

  
  private async getEligibleRoutes(request) {
    return new Promise<void>((resolve, reject) => {
      var directionsService = new google.maps.DirectionsService();
      directionsService.route(request, async (response, status) => {
        if (status == 'OK') {
          const distance = response.routes[0].legs[0].distance.value / 1000;
          const path: Array<any> = response.routes[0].legs[0].steps.reduce((acc, step) => acc.concat(...step.path), []);
          const stepOffset = (path.length / distance) * PATH_ELIGIBILITY_OFFSET;
          let isSourceEligible, isDestEligible;
          
          let routeIndex = -1; // Variable to store the index of the route
              const routes = this.passengerService.availableRoutes
          // Iterate over the available routes
          for (let i = 0; i < routes.length; i++) {
              const route = routes[i];
              // Check if the current route matches the request
              if (route.origin === request.origin && route.destination === request.destination) {
                  routeIndex = i; // Assign the index of the route
                  break; // Exit the loop once the route is found
              }
          }
          const pickupLocation = this.pickupLocation.pickupLocation;
          for (let i = 0; i <= path.length; i += stepOffset) {
            this.destinationOffsetStep = i;
            isSourceEligible = await this.checkDistanceEligibility(path[Math.round(i)].toJSON(), pickupLocation);
            if (isSourceEligible) {
              break;
            }
          }
          const dropoffLocation = this.dropoffLocation.dropoffLocation;
          for (let i = this.destinationOffsetStep; i <= path.length; i += stepOffset) {
            isDestEligible = await this.checkDistanceEligibility(path[Math.round(i)].toJSON(), dropoffLocation);
            if (isDestEligible) {
              break;
            }
          }
          if (isSourceEligible && isDestEligible) {
            // Iterate over all available routes and find matches
            const driverDepartureDate = this.departureDate.departureDate;
            this.passengerService.initializeRoutes();

            this.passengerService.availableRoutes.forEach((route: any, routeIndex) => {
              console.log('Checking route', route);
              if (route.origin === request.origin && route.destination === request.destination) {
                const routeName = this.passengerService.userNames[routeIndex];
                const userImage = this.passengerService.userImages[routeIndex];
                const passengerOrigin = this.passengerService.availableRoutes[routeIndex].origin;
                const passengerDestination = this.passengerService.availableRoutes[routeIndex].destination;
                const passengerUserId = this.passengerService.userId[routeIndex];
                const passengerRideId = this.passengerService.PassengerRiderID[routeIndex];
                const passengerDepartureDate = this.passengerService.departureDates[routeIndex];

               if(passengerDepartureDate === passengerDepartureDate){
                this.eligiblePassengers.push({
                  passengerRideId: passengerRideId,
                  image: userImage,
                  name: routeName,
                  origin: passengerOrigin,
                  destination: passengerDestination,
                  passengerUserId: passengerUserId
                });
               }else {
                console.log('Departure date does not much')
               }
  
                //if (!this.eligiblePassengers.some(passenger => passenger.name === routeName && passenger.passengerUserId === passengerUserId)) {
                  
                //}
              }
            });
          }
          resolve(); // Resolve the promise after processing the route
        } else {
          reject(`Failed to get directions for route. Status: ${status}`);
        }
      });
    });
  }
  
private async checkDistanceEligibility(pointA: LatLng, pointB: string): Promise<boolean> {
  const x = new google.maps.LatLng(pointA.lat, pointA.lng);
  var service = new google.maps.DistanceMatrixService();
  return service.getDistanceMatrix(
    {
      origins: [x],
      destinations: [pointB],
      travelMode: 'DRIVING',
    }).then((response, status) => {
      if(!response.rows[0].elements[0].distance){ return false}
      const dist = response.rows[0].elements[0].distance.value / 1000;
      console.log(dist);
      return dist <= PATH_ELIGIBILITY_OFFSET;
    });
}



  resetForm() {
  
    this.driverDetail = null; // Reset passenger details
    
    // Reset other relevant form controls and properties
    this.departureDate = null;
    this.seats = null;
    this.luggage = null;
    this.departureTime = null;
    this.additionalDetails = null;
    
    // Reset pickup and dropoff locations
    this.pickupLocation = null;
    this.dropoffLocation = null;
  }
  

  goToMyRides(){
    this.router.navigate(['/driver-myride']);
  }


onPassengerClick(passenger: any) {
  const passengerData = {
    ...passenger,
    departureDate: this.departureDate,
    departureTime: this.departureTime,
    seats: this.seats,
    luggage: this.luggage,
    additionalDetails: this.additionalDetails,
    pickupLocation: this.pickupLocation,
    dropoffLocation: this.dropoffLocation
    
  };
  this.router.navigate(['/matched-passenger-detail'], { state: { passenger: passengerData } });
}



}
