import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AlertController, NavController } from '@ionic/angular';
import { AuthService } from 'src/app/auth/auth.service';
import { RideService } from 'src/app/passenger/passenger-rides-request/ride.service';

@Component({
  selector: 'app-driver-rides-request',
  templateUrl: './driver-rides-request.component.html',
  styleUrls: ['./driver-rides-request.component.scss'],
})
export class DriverRidesRequestComponent  implements OnInit {

  rideRequests: any[] = [];
  showDetails: { [key: string]: boolean } = {}; // Track visibility of details for each request
  passengerId: string;

  constructor(
    private rideService: RideService,
    private authService: AuthService,
    private http: HttpClient,
    private navCtrl: NavController,
    private alertController: AlertController
  ) {}

  ngOnInit() {
    this.authService.userId.subscribe(userId => {
      this.passengerId = userId;
      console.log(this.passengerId);
      this.fetchRideRequests();
    });
  }

  fetchRideRequests() {
    this.rideService.getRideRequests().subscribe(requests => {
      console.log('Ride requests received:', requests);
      this.rideRequests = [];

      if (requests) {
        const keys = Object.keys(requests);
        for (let key of keys) {
          if (requests[key].passengerId === this.passengerId) {
            this.rideRequests.push({ id: key, ...requests[key] });
            this.showDetails[key] = false; // Initialize detail visibility
          }
        }
      }
    });
  }

  toggleDetails(requestId: string) {
    this.showDetails[requestId] = !this.showDetails[requestId];
  }

  acceptRide(request: any) {
    const booking = {
      driverId: request.driverId,
      passengerId: request.passengerId,
      rideId: this.generateUniqueId(),
      origin: request.origin,
      destination: request.destination,
      departureDate: request.departureDate,
      departureTime: request.departureTime,
      seats: request.seats,
      luggage: request.luggage,
      additionalDetails: request.additionalDetails,
    };

    console.log(booking);

    this.rideService.acceptRideRequest(booking).subscribe(
      async response => {
        console.log('Booking response:', response);

        // Delete the accepted ride request from riderequests.json
        this.rideService.deleteRideRequests(request.id).subscribe(
          async () => {
            console.log('Ride request deleted');

            // Remove the accepted request from the local list
            this.rideRequests = this.rideRequests.filter(r => r.id !== request.id);

            const alert = await this.alertController.create({
              header: 'Booking Successful',
              message: 'Thank you for booking the ride!',
              buttons: ['OK']
            });
            await alert.present();

            // Navigate to booking component
            this.navCtrl.navigateForward('/booking', {
              queryParams: {
                bookingId: booking.rideId
              }
            });
          },
          error => {
            console.error('Error deleting ride request:', error);
          }
        );
      },
      error => {
        console.error('Error posting booking:', error);
      }
    );
  }

  generateUniqueId() {
    // Simple unique ID generator
    return 'ride-' + Math.random().toString(36).substr(2, 9);
  }

  cancelRide(requestId: string) {
    this.rideRequests = this.rideRequests.filter(r => r.id !== requestId);
    console.log('Ride request cancelled');
  }

}
