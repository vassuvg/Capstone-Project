/*import { Injectable, OnDestroy } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, from, Observable, throwError } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { Storage } from '@capacitor/storage';
import { Router } from '@angular/router';
import { User } from './user.model';
import { auth } from 'src/firebase.init';
import {
  GoogleAuthProvider,
  signInWithRedirect,
  getRedirectResult,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  Auth,
} from 'firebase/auth';

export interface AuthResponseData {
  kind: string;
  idToken: string;
  email: string;
  refreshToken: string;
  localId: string;
  expiresIn: string;
  registered?: boolean;
}

@Injectable({
  providedIn: 'root',
})
export class AuthService implements OnDestroy {
  private _user = new BehaviorSubject<User | null>(null);
  private activeLogoutTimer: any;
  private userIdSubject = new BehaviorSubject<string | null>(null);

  constructor(private http: HttpClient, private router: Router) {}

  get userIsAuthenticated() {
    return this._user.asObservable().pipe(map((user) => !!user?.token));
  }

  get userId$() {
    return this.userIdSubject.asObservable();
  }

  autoLogin() {
    return from(Storage.get({ key: 'authData' })).pipe(
      map((storedData) => {
        if (!storedData || !storedData.value) {
          return null;
        }
        const parsedData = JSON.parse(storedData.value) as {
          token: string;
          tokenExpirationDate: string;
          userId: string;
          email: string;
        };
        const expirationTime = new Date(parsedData.tokenExpirationDate);
        if (expirationTime <= new Date()) {
          return null;
        }
        return new User(
          parsedData.userId,
          parsedData.email,
          parsedData.token,
          expirationTime
        );
      }),
      tap((user) => {
        if (user) {
          this._user.next(user);
          this.userIdSubject.next(user.id);
          this.autoLogout(user.tokenDuration);
        }
      }),
      map((user) => !!user)
    );
  }

  signup(email: string, password: string) {
    return from(
      createUserWithEmailAndPassword(auth, email, password)
    ).pipe(
      tap((userCredential) => {
        const user = userCredential.user;
        user.getIdToken().then((token) => {
          const userData: AuthResponseData = {
            kind: '',
            idToken: token,
            email: user.email!,
            refreshToken: user.refreshToken,
            localId: user.uid,
            expiresIn: '3600',
          };
          this.setUserData(userData);
        });
      }),
      catchError((error) => this.handleError(error))
    );
  }

  login(email: string, password: string) {
    return from(signInWithEmailAndPassword(auth, email, password)).pipe(
      tap((userCredential) => {
        const user = userCredential.user;
        user.getIdToken().then((token) => {
          const userData: AuthResponseData = {
            kind: '',
            idToken: token,
            email: user.email!,
            refreshToken: user.refreshToken,
            localId: user.uid,
            expiresIn: '3600',
          };
          this.setUserData(userData);
        });
      }),
      catchError((error) => this.handleError(error))
    );
  }

  loginWithGoogle() {
    const provider = new GoogleAuthProvider();
    signInWithRedirect(auth, provider);
  }

  handleRedirectResult() {
    return from(getRedirectResult(auth)).pipe(
      tap((result) => {
        if (result) {
          const user = result.user;
          user.getIdToken().then((token) => {
            const userData: AuthResponseData = {
              kind: '',
              idToken: token,
              email: user.email!,
              refreshToken: user.refreshToken,
              localId: user.uid,
              expiresIn: '3600',
            };
            this.setUserData(userData);
          });
        }
      }),
      catchError((error) => this.handleError(error))
    );
  }

  logout() {
    if (this.activeLogoutTimer) {
      clearTimeout(this.activeLogoutTimer);
    }
    this._user.next(null);
    this.userIdSubject.next(null);

    Storage.remove({ key: 'authData' }).then(() => {
      console.log('Auth data cleared from storage.');
    });

    this.router.navigateByUrl('/auth'); // Redirect to login page
  }

  ngOnDestroy(): void {
    if (this.activeLogoutTimer) {
      clearTimeout(this.activeLogoutTimer);
    }
  }

  private autoLogout(duration: number) {
    if (this.activeLogoutTimer) {
      clearTimeout(this.activeLogoutTimer);
    }
    this.activeLogoutTimer = setTimeout(() => {
      this.logout();
    }, duration);
  }

  private setUserData(userData: AuthResponseData) {
    const expirationTime = new Date(
      new Date().getTime() + +userData.expiresIn * 1000
    );
    const user = new User(
      userData.localId,
      userData.email,
      userData.idToken,
      expirationTime
    );
    this._user.next(user);
    this.userIdSubject.next(user.id);
    this.autoLogout(user.tokenDuration);
    this.storeAuthData(
      userData.localId,
      userData.idToken,
      expirationTime.toISOString(),
      userData.email
    );
  }

  private storeAuthData(
    userId: string,
    token: string,
    tokenExpirationDate: string,
    email: string
  ) {
    const data = JSON.stringify({
      userId,
      token,
      tokenExpirationDate,
      email,
    });
    Storage.set({ key: 'authData', value: data });
  }

  private handleError(error: any) {
    let errorMessage = 'An unknown error occurred!';
    if (error.code === 'auth/email-already-in-use') {
      errorMessage = 'This email address is already in use.';
    } else if (
      error.code === 'auth/user-not-found' ||
      error.code === 'auth/wrong-password'
    ) {
      errorMessage = 'Invalid credentials. Please try again.';
    }
    this.showAlert(errorMessage);
    return throwError(errorMessage);
  }

  private showAlert(message: string) {
    // You can implement your alert logic here
    console.error('Error occurred:', message);
  }
}
*/
import { Inject, Injectable, OnDestroy } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, from } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { Storage } from '@capacitor/storage';
import { Router } from '@angular/router';
import { User } from './user.model';
import { initializeApp } from 'firebase/app';
import { AuthProvider, GoogleAuthProvider, UserCredential, fetchSignInMethodsForEmail, getAuth, getRedirectResult, signInWithPopup, signInWithRedirect, signOut } from 'firebase/auth';
import { AlertController } from '@ionic/angular';
import { ProfileService } from '../profile/profile.service';
import { DOCUMENT } from '@angular/common';
import { FirebaseAuthentication } from '@ionic-native/firebase-authentication/ngx';
import { Capacitor } from '@capacitor/core';

 import { Browser} from '@capacitor/browser';


export interface AuthResponseData {
  kind: string;
  idToken: string;
  email: string;
  refreshToken: string;
  localId: string;
  expiresIn: string;
  registered?: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService implements OnDestroy {
  private _user = new BehaviorSubject<User>(null);
  private activeLogoutTimer: any;
  private auth;
  private _profileIsComplete = new BehaviorSubject<boolean>(false);
  private apiKey: string = environment.firebase.apiKey;

  private emulatorBaseUrl = 'http://localhost:8100/emulator/v1/projects/driveshare-c4036}'

 


  

  sendVerificationCode(phoneNumber: string) {
    const url = `${this.emulatorBaseUrl}/verificationCodes`;
    const body = {
      phoneNumber: phoneNumber,
      // You can add more parameters if needed
    };

    return this.http.post(url, body);
  }

  
 

  get userIsAuthenticated() {
    return this._user.asObservable().pipe(
      map(user => !!user?.token)
    );
  }

  get userId() {
    return this._user.asObservable().pipe(
      map(user => user?.id ?? null)
    );
  }
  get emailId() {
    return this._user.asObservable().pipe(
      map(user => user?.email ?? null)
    );
  }

  constructor(private http: HttpClient, private router: Router,     private alertCtrl: AlertController, private profileService: ProfileService
    , @Inject(DOCUMENT) private document: Document, private firebaseAuthentication: FirebaseAuthentication) {
    const firebase = environment.firebase;
    const app = initializeApp(firebase);
    this.auth = getAuth(app);

   }
   

  
  //actual method
  async googleSignIn() {
    const provider = new GoogleAuthProvider();
    try {
      if (Capacitor.isNativePlatform()) {
        // Use system browser for native platforms
        const authUrl = await this.getAuthUrl(provider);
        await Browser.open({ url: authUrl });
      } else {
        // Use popup for web platforms
        await signInWithPopup(this.auth, provider).then((result: UserCredential) => {
          const user = result.user;
          user.getIdToken().then((token: string) => {
            this.setUserData({
              kind: 'identitytoolkit#VerifyCustomTokenResponse',
              idToken: token,
              email: user.email,
              refreshToken: user.refreshToken,
              localId: user.uid,
              expiresIn: '3600',
            });
          });
          this.profileService.getProfile(user.uid).subscribe(profile => {
            if (profile) {
              this.router.navigate(['/home']);
            } else {
              this.router.navigate(['/profile']);
            }
          });
        });
      }
    } catch (error) {
      console.error('Error signing in with Google:', error);
    }
  }
  
  async getAuthUrl(provider: AuthProvider): Promise<string> {
    const auth = getAuth();
    const authUrl = await signInWithRedirect(auth, provider);
    return authUrl;
  }
  autoLogin() {
    return from(Storage.get({ key: 'authData' })).pipe(
      map(storedData => {
        if (!storedData || !storedData.value) {
          return null;
        }
        const parsedData = JSON.parse(storedData.value) as { token: string; tokenExpirationDate: string; userId: string; email: string };
        const expirationTime = new Date(parsedData.tokenExpirationDate);
        if (expirationTime <= new Date()) { return null; }
        return new User(parsedData.userId, parsedData.email, parsedData.token, expirationTime);
      }),
      tap(user => {
        if (user) {
          this._user.next(user);
          this.autoLogout(user.tokenDuration);
        }
      }),
      map(user => !!user)
    );
  }

  signup(email: string, password: string) {
    return this.http.post<AuthResponseData>(
      `https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=${environment.firebase.apiKey}`,
      { email, password, returnSecureToken: true }
    ).pipe(tap(this.setUserData.bind(this)));
  }

  login(email: string, password: string) {
    return this.http.post<AuthResponseData>(
      `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${environment.firebase.apiKey}`,
      { email, password, returnSecureToken: true }
    ).pipe(tap(this.setUserData.bind(this)));
  }

 

  logout() {
    if (this.activeLogoutTimer) {
      clearTimeout(this.activeLogoutTimer);
      this.activeLogoutTimer = null; // Clear the reference to the timer
    }
    this._user.next(null);
  
    Storage.remove({ key: 'authData' }).then(() => {
      console.log('Auth data cleared from storage.');
    });
  
    this.document.location.reload();
    this.router.navigateByUrl('/auth'); 
    // Redirect to login page
    return signOut(this.auth);
  }
  
  
  ngOnDestroy(): void {
    if (this.activeLogoutTimer) {
      clearTimeout(this.activeLogoutTimer);
    }
  }
  

  private autoLogout(duration: number) {
    if (this.activeLogoutTimer) {
      clearTimeout(this.activeLogoutTimer);
    }
    this.activeLogoutTimer = setTimeout(() => {
      this.logout();
    }, duration);
  }
  

  private setUserData(userData: AuthResponseData) {
    const expirationTime = new Date(new Date().getTime() + (+userData.expiresIn * 1000));
    const user = new User(userData.localId, userData.email, userData.idToken, expirationTime);
    this._user.next(user);
    this.autoLogout(user.tokenDuration);
    this.storeAuthData(userData.localId, userData.idToken, expirationTime.toISOString(), userData.email);
  }

  private storeAuthData(userId: string, token: string, tokenExpirationDate: string, email: string) {
    const data = JSON.stringify({ userId, token, tokenExpirationDate, email });
    Storage.set({ key: 'authData', value: data });
  }

 

  private showAlert(message: string) {
    this.alertCtrl
      .create({
        header: 'Authentication failed',
        message: message,
        buttons: ['Okay']
      })
      .then(alertEl => alertEl.present());
  }
}
