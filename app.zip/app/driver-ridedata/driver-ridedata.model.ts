export class DriverRideData {
    public departureDate: Date;
     public departureTime: string;
     public seats: number;
     public luggage: number;
     public additionalDetails: string;
     public pickupLocation: string; // Add pickup location field
     public dropoffLocation: string; 
 userId: any;
 }
 