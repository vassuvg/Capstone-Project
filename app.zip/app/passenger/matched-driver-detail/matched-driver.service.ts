import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { DriverRideData } from 'src/app/driver-ridedata/driver-ridedata.model';

@Injectable({
  providedIn: 'root',
})
export class MatchedDriverService {

    //rideData : any[] = []


   
constructor(private http: HttpClient){
 this.initializeRideData();
}
initializeRideData() {
      
}


getDriverRideDetails(userId: string, rideId: string) {
  return this.http.get<DriverRideData>(`https://driveshare-c4036-default-rtdb.firebaseio.com/driverRideData/${userId}/${rideId}.json`);
}



}