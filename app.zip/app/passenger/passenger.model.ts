export class Passenger {
    pickupLocation: string;
    dropoffLocation: string;
    departureDate: string;
    departureTime: string;
    luggage: string;
    additionalDetails: string;
    passengerCount: number;
  }
  
  