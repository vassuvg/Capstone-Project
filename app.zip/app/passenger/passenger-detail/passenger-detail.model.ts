export class PassengerDetail {
    public departureDate: Date;
    public departureTime: string;
    public seats: number;
    public luggage: number;
    public additionalDetails: string;
    public pickupLocation: string; // Add pickup location field
    public dropoffLocation: string; // Add dropoff location field
    public userId: string;
  }
  
  