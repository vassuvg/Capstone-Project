import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RideService {
    private baseUrl = 'https://driveshare-c4036-default-rtdb.firebaseio.com';

    private rideRequestSubject = new BehaviorSubject<any>(null);
    private acceptedRequestSubject = new BehaviorSubject<any>(null);
  
    constructor(private http: HttpClient) {}
  
    // Method to send a ride request
    sendRideRequest(rideRequest: any) {
        return this.http.post(`${this.baseUrl}/pendingRideRequestsByPassenger.json`, rideRequest);
      }
  
   
  getRideRequest(): Observable<any> {
    return this.http.get(`${this.baseUrl}/pendingRideRequestsByPassenger.json`);
  }


  sendRideRequests(rideRequest: any) {
    return this.http.post(`${this.baseUrl}/pendingRideRequestsByDriver.json`, rideRequest);
  }


getRideRequests(): Observable<any> {
return this.http.get(`${this.baseUrl}/pendingRideRequestsByDriver.json`);
}
  
    acceptRideRequest(booking: any): Observable<any> {
        return this.http.post(`${this.baseUrl}/acceptedrides.json`, booking);
      }
  
    // Method to get the accepted ride request
    getAcceptedRequest(): Observable<any> {
      return this.acceptedRequestSubject.asObservable();
    }
  
    // Method to post the booking to Firebase
      private postBookingToFirebase(booking: any) {
      this.http.post('https://driveshare-c4036-default-rtdb.firebaseio.com/bookings.json', booking)
        .subscribe(response => {
          console.log('Booking posted to Firebase:', response);
        }, error => {
          console.error('Error posting booking to Firebase:', error);
        });
    }

    deleteRideRequest(rideRequestId: string): Observable<any> {
        return this.http.delete(`${this.baseUrl}/pendingRideRequestsByPassenger/${rideRequestId}.json`);
      }

      deleteRideRequests(rideRequestId: string): Observable<any> {
        return this.http.delete(`${this.baseUrl}/pendingRideRequestsByDriver/${rideRequestId}.json`);
      }
}