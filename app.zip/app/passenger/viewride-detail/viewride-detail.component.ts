import { Component, Inject, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { PassengerService } from '../passenger.service';
import { PassengerDetailService } from '../passenger-detail.service';
import { ActivatedRoute, Router } from '@angular/router';
import { PassengerDetail } from '../passenger-detail/passenger-detail.model';
import { DriverService } from 'src/app/driver/driver.service';
import { AlertController, LoadingController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { AuthService } from 'src/app/auth/auth.service';
import { take } from 'rxjs/operators';
import { Subscription } from 'rxjs/internal/Subscription';
import { DOCUMENT } from '@angular/common';
import { ProfileService } from 'src/app/profile/profile.service';

export const PATH_ELIGIBILITY_OFFSET = 5;

export type LatLng = { lat: number, lng: number };
declare var google;

@Component({
  selector: 'app-viewride-detail',
  templateUrl: './viewride-detail.component.html',
  styleUrls: ['./viewride-detail.component.scss'],
})
export class ViewrideDetailComponent implements OnInit, OnDestroy {
  Passengerstate: any;
  pickupQuery: string;
  dropoffQuery: string;
  passengerDetail: any; // Ensure passengerDetail is defined
  destinationOffsetStep = 0;
  eligibleDrivers: {
    driverRideId: string;
    image: string;
    name: string;
    origin: string;
    destination: string;
    driverUserId: string;
    gender: string;
  }[] = [];
  userId: string;
  pickupLocation: any;
  dropoffLocation: any;
  genderPreference: 'female' | 'any' = 'any';

  @ViewChild('mapElement', { static: false }) mapElement;
  directionsService = new google.maps.DirectionsService();
  directionsRenderer = new google.maps.DirectionsRenderer();

  private authSub: Subscription;

  departureDate: any;
  seats: any;
  luggage: any;
  DriverRideID: any;
  departureTime: any;
  additionalDetails: any;
  constructor(
    @Inject(DOCUMENT) private document: Document,
    private passengerService: PassengerService,
    private passengerDetailService: PassengerDetailService,
    private driverService: DriverService,
    private loadingController: LoadingController,
    private alertController: AlertController,
    private http: HttpClient,
    private authService: AuthService,
    private router: Router,
    private profileService: ProfileService
  ) {}

  ngOnInit() {
    console.log('Oninit called');
    this.authSub = this.authService.userIsAuthenticated.subscribe((isAuth) => {
      if (!isAuth) {
        this.resetForm();
      } else {
        this.initializeData();
      }
    });
    this.authService.userId.pipe(take(1)).subscribe((userId) => {
      this.userId = userId;
      this.initializeData();
    });
  }

  ngOnDestroy() {
    console.log('ondestroycalled');
    if (this.authSub) {
      this.authSub.unsubscribe();
    }

    this.document.location.reload();
  }

  initializeData() {
    console.log('User ID:', this.userId);
    this.passengerService.getPassengerState().subscribe((x: any) => {
      this.Passengerstate = x;
    });
    console.log(
      'Got passenger state from passenger detail page',
      this.Passengerstate
    );

    this.http
      .get<any>(
        `https://driveshare-c4036-default-rtdb.firebaseio.com/passengerDetails/${this.userId}.json`
      )
      .subscribe(
        (passengerDetailResponse: any) => {
          console.log('Passenger Details:', passengerDetailResponse);
          if (passengerDetailResponse) {
            let mostRecentPassengerDetails = Object.values(
              passengerDetailResponse
            ).find((passenger: any) => passenger.userId === this.userId);
            for (const key in passengerDetailResponse) {
              if (passengerDetailResponse.hasOwnProperty(key)) {
                const passenger = passengerDetailResponse[key];
                console.log('Passenger:', passenger);

                if (passenger.userId === this.userId) {
                  mostRecentPassengerDetails = passenger;
                }
              }
            }
            if (mostRecentPassengerDetails) {
              this.departureDate = mostRecentPassengerDetails;
              this.seats = mostRecentPassengerDetails;
              this.luggage = mostRecentPassengerDetails;
              this.departureTime = mostRecentPassengerDetails;
              this.additionalDetails = mostRecentPassengerDetails;
              this.pickupLocation = mostRecentPassengerDetails;
              this.dropoffLocation = mostRecentPassengerDetails;
            }
          }
        },
        (error) => {
          console.error('Error fetching passenger details:', error);
        }
      );
  }

  async onViewMatches() {
    // Get the user's profile to determine gender
    const profile = await this.profileService.getProfile(this.userId).pipe(take(1)).toPromise();
  
    if (profile && (profile.gender === 'female')) {
      // Prompt the user to choose a preferred driver gender
      const genderAlert = await this.alertController.create({
        header: 'Select Driver Preference',
        inputs: [
         
          {
            name: 'female',
            type: 'radio',
            label: 'Female',
            value: 'female'
          },
          {
            name: 'any',
            type: 'radio',
            label: 'Any',
            value: 'any'
          }
        ],
        buttons: [
          {
            text: 'Cancel',
            role: 'cancel',
            handler: () => {
              return;
            }
          },
          {
            text: 'OK',
            handler: (selectedGender) => {
              this.searchForEligibleDrivers(selectedGender);
            }
          }
        ]
      });
  
      await genderAlert.present();
    } else {
      // If the profile doesn't specify gender, skip the gender preference step
      this.searchForEligibleDrivers('any');
    }
  }
  private async searchForEligibleDrivers(preferredGender: string) {
    const loading = await this.loadingController.create({
      message: 'Loading...',
      translucent: true,
      spinner: 'bubbles',
    });
  
    try {
      await loading.present(); // Show the loading indicator
  
      this.eligibleDrivers = [];
      const routes = this.driverService.availableRoutes;
  
      // Fetch eligible routes based on the preferred gender
      await Promise.all(routes.map((route) => this.getEligibleRoutes(route, preferredGender)));
    } catch (error) {
      console.error('Error fetching eligible routes:', error);
      const alert = await this.alertController.create({
        header: 'Error',
        message: 'Failed to fetch eligible routes. Please try again later.',
        buttons: ['OK'],
      });
      await alert.present();
    } finally {
      try {
        await loading.dismiss(); // Dismiss the loading indicator
      } catch (dismissError) {
        console.error('Error dismissing loading indicator:', dismissError);
      }
  
      if (this.eligibleDrivers.length === 0) {
        const alert = await this.alertController.create({
          header: 'No Matches',
          message: 'No matching drivers found.',
          buttons: ['OK'],
        });
        await alert.present();
      }
    }
  }
  

 /* async onViewMatches() {
   const loading = await this.loadingController.create({
      message: 'Loading...',
      translucent: true,
      spinner: 'bubbles',
    });
    await loading.present();

    this.eligibleDrivers = [];
    const routes = this.driverService.availableRoutes;

    try {
      await Promise.all(routes.map((route) => this.getEligibleRoutes(route)));
    } catch (error) {
      console.error('Error fetching eligible routes:', error);
      const alert = await this.alertController.create({
        header: 'Error',
        message: 'Failed to fetch eligible routes. Please try again later.',
        buttons: ['OK'],
      });
      await alert.present();
    } finally {
      await loading.dismiss();
      if (this.eligibleDrivers.length === 0) {
        const alert = await this.alertController.create({
          header: 'No Matches',
          message: 'No matching drivers found.',
          buttons: ['OK'],
        });
        await alert.present();
      }
    }
    
  }*/



  private async getEligibleRoutes(request, preferredGender: string) {
    return new Promise<void>((resolve, reject) => {
      var directionsService = new google.maps.DirectionsService();
      directionsService.route(request, async (response, status) => {
        if (status == 'OK') {
          const distance = response.routes[0].legs[0].distance.value / 1000;
          const path: Array<any> = response.routes[0].legs[0].steps.reduce(
            (acc, step) => acc.concat(...step.path),
            []
          );
          const stepOffset = (path.length / distance) * PATH_ELIGIBILITY_OFFSET;
          let isSourceEligible, isDestEligible;

          const pickupLocation = this.pickupLocation.pickupLocation;
          const dropoffLocation = this.dropoffLocation.dropoffLocation;
          console.log(pickupLocation, dropoffLocation);

          for (let i = 0; i <= path.length; i += stepOffset) {
            this.destinationOffsetStep = i;
            isSourceEligible = await this.checkDistanceEligibility(
              path[Math.round(i)].toJSON(),
              pickupLocation
            );
            if (isSourceEligible) {
              break;
            }
          }

          for (let i = this.destinationOffsetStep; i <= path.length; i += stepOffset) {
            isDestEligible = await this.checkDistanceEligibility(
              path[Math.round(i)].toJSON(),
              dropoffLocation
            );
            if (isDestEligible) {
              break;
            }
          }

          if (isSourceEligible && isDestEligible) {
            console.log('Source and destination are eligible. Checking available routes...');

            const passengerDepartureDate = this.departureDate.departureDate;
            this.driverService.initializeRoutes();

            this.driverService.availableRoutes.forEach((route: any, routeIndex) => {
              console.log('Checking route:', route);
              if (route.origin === request.origin && route.destination === request.destination) {
                const routeName = this.driverService.userNames[routeIndex];
                const userImage = this.driverService.userImages[routeIndex];
                const driverOrigin = this.driverService.availableRoutes[routeIndex].origin;
                const driverDestination = this.driverService.availableRoutes[routeIndex].destination;
                const driverUserId = this.driverService.userId[routeIndex];
                const driverDepartureDate = this.driverService.departureDates[routeIndex];
                const driverRideId = this.driverService.DriverRiderID[routeIndex];
                const driverGender = this.driverService.gender[routeIndex];

                console.log('Driver Departure Date:', driverDepartureDate);
                console.log('Passenger Departure Date:', passengerDepartureDate);
                console.log('RideID', driverRideId);

                if (driverDepartureDate === passengerDepartureDate) {
                  console.log('Departure date matches.');
            // if (!this.eligibleDrivers.some(driver => driver.name === routeName && driver.driverUserId === driverUserId)) {
              if (preferredGender === 'any' || driverGender === preferredGender) {  
            this.eligibleDrivers.push({
                      driverRideId: driverRideId,
                      image: userImage,
                      name: routeName,
                      origin: driverOrigin,
                      destination: driverDestination,
                      driverUserId: driverUserId,
                      gender: driverGender
                    });
             //  }
                  }
                } else {
                  console.log('Departure date does not match.');
                }
              }
              
           });
          }
          resolve();
        } else {
          reject(`Failed to get directions for route. Status: ${status}`);
        }
      });
    });
  }

  private async checkDistanceEligibility(currentLocation, targetLocation) {
    return new Promise<boolean>((resolve, reject) => {
      const distanceService = new google.maps.DistanceMatrixService();
      distanceService.getDistanceMatrix(
        {
          origins: [currentLocation],
          destinations: [targetLocation],
          travelMode: google.maps.TravelMode.DRIVING,
        },
        (response, status) => {
          if (status === 'OK') {
            const distance = response.rows[0].elements[0].distance.value;
            resolve(distance <= 5000); // 5km radius
          } else {
            reject(`Failed to get distance for location. Status: ${status}`);
          }
        }
      );
    });
  }

  resetForm() {
    this.passengerDetail = {};
    this.Passengerstate = {};
    this.pickupQuery = '';
    this.dropoffQuery = '';
  }


onDriverClick(driver: any) {
  const driverData = {
    ...driver,
    departureDate: this.departureDate,
    departureTime: this.departureTime,
    seats: this.seats,
    luggage: this.luggage,
    additionalDetails: this.additionalDetails,
    pickupLocation: this.pickupLocation,
    dropoffLocation: this.dropoffLocation
    
  };
  this.router.navigate(['/matched-driver-detail'], { state: { driver: driverData } });
}

}
