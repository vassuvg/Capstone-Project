import { Injectable } from '@angular/core';
import { PassengerDetail } from './passenger-detail/passenger-detail.model';


@Injectable({
  providedIn: 'root'
})
export class PassengerDetailService {
    private passengerDetail: PassengerDetail;

    constructor() { }
  
    setPassengerDetail(passengerDetail: PassengerDetail) {
      this.passengerDetail = passengerDetail;
    }
  
    getPassengerDetail(): PassengerDetail {
      return this.passengerDetail;
    }
}
