import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AuthGuard } from './auth/auth.guard';
import { PassengerDetailComponent } from './passenger/passenger-detail/passenger-detail.component';
import { ViewrideDetailComponent } from './passenger/viewride-detail/viewride-detail.component';
import { ViewdriverRideinfoComponent } from './viewdriver-rideinfo/viewdriver-rideinfo.component';
import { AccountMyInformationComponent } from './account/account-my-information/account-my-information.component';
import { AccountDriverInformationComponent } from './account/account-driver-information/account-driver-information.component';
import { MatchedDriverDetailComponent } from './passenger/matched-driver-detail/matched-driver-detail.component';
import { MatchedPassengerDetailComponent } from './viewdriver-rideinfo/matched-passenger-detail/matched-passenger-detail.component';
import { PassengerRidesRequestComponent } from './passenger/passenger-rides-request/passenger-rides-request.component';
import { DriverRidesRequestComponent } from './viewdriver-rideinfo/driver-rides-request/driver-rides-request.component';
import { PassengerHomeComponent } from './passenger-home/passenger-home.component';
import { DriverHomeComponent } from './driver-home/driver-home.component';
import { StartRideComponent } from './booking/start-ride/start-ride.component';

const routes: Routes = [
  { path: '', redirectTo: 'auth', pathMatch: 'full' }, // Redirect to auth
  { path: 'auth', loadChildren: () => import('./auth/auth.module').then(m => m.AuthPageModule) },
  { path: 'home', component: HomeComponent, canActivate: [AuthGuard] },
  { path: 'passenger-home', component: PassengerHomeComponent, canActivate: [AuthGuard] },
  { path: 'passenger', loadChildren: () => import('./passenger/passenger.module').then(m => m.PassengerPageModule), canActivate: [AuthGuard] },
  { path: 'passenger-detail', component: PassengerDetailComponent, canActivate: [AuthGuard] },
  { path: 'viewride-detail', component: ViewrideDetailComponent, canActivate: [AuthGuard] },
  { path: 'matched-driver-detail', component: MatchedDriverDetailComponent, canActivate: [AuthGuard] },
  { path: 'viewride-driverdetail', component: ViewdriverRideinfoComponent, canActivate: [AuthGuard] },
  { path: 'matched-passenger-detail', component: MatchedPassengerDetailComponent, canActivate: [AuthGuard] },
  { path: 'driver-rides-request', component: DriverRidesRequestComponent, canActivate: [AuthGuard]},
  { path: 'passenger-rides-request', component: PassengerRidesRequestComponent, canActivate: [AuthGuard] },
  { path: 'driver-home', component: DriverHomeComponent, canActivate: [AuthGuard] },
  { path: 'driver-rideinfo', loadChildren: () => import('./driver-rideinfo/driver-rideinfo.module').then(m => m.DriverRideModule), canActivate: [AuthGuard] },
  { path: 'driver', loadChildren: () => import('./driver/driver.module').then(m => m.DriverModule), canActivate: [AuthGuard] },
  { path: 'account', loadChildren: () => import('./account/account.module').then(m => m.AccountModule), canActivate: [AuthGuard] },
  { path: 'account-my-information', component: AccountMyInformationComponent, canActivate: [AuthGuard] },
  { path: 'account-driver-information', component: AccountDriverInformationComponent, canActivate: [AuthGuard] },
  { path: 'driver-detail', loadChildren: () => import('./driver-detail/driver-detail.module').then(m => m.DriverDetailModule), canActivate: [AuthGuard] },
  { path: 'driver-ridedatadetail', loadChildren: () => import('./driver-ridedata/driver-ridedata.module').then(m => m.DriverRideDataPageModule), canActivate: [AuthGuard] },
  { path: 'driver-myride', loadChildren: () => import('./driver-myrides/driver-myrides.module').then(m => m.ViewDriverRideInfoModule), canActivate: [AuthGuard] },
  { path: 'profile', loadChildren: () => import('./profile/profile.module').then(m => m.ProfileModule), canActivate: [AuthGuard] },
  { path: 'pwd-reset', loadChildren: () => import('./pwdreset/pwdreset.module').then(m => m.PwdResetModule) },
  { path: 'booking', loadChildren: () => import('./booking/booking.module').then(m=> m.BookingModule), canActivate: [AuthGuard]},
  {path: 'start-ride', component: StartRideComponent, canActivate: [AuthGuard]},
  { path: 'booking-passenger', loadChildren: () => import('./booking-passenger/booking-passenger.module').then(m=> m.BookingPassengerModule), canActivate: [AuthGuard]}
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
