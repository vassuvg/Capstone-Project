import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class LicenseVerificationService {
  /*constructor(private http: HttpClient) {}

  verifyLicense(documentNumber: string): Observable<any> {
    // Mock API call
    return of({
      data: {
        documentNumber: documentNumber,
        licenceStatus: 'Valid',
        verificationNumber: '826XY'
      },
      signature: {
        dateTime: 'August 28, 2023 8:03 PM',
        message: 'Certified by Verifik.co'
      },
      id: '9t9le'
    }).pipe(
      catchError(error => {
        console.error('Error verifying license', error);
        return of({ error: 'Verification failed' });
      })
    );
  }*/

  private apiUrl = 'https://driveshare-c4036-default-rtdb.firebaseio.com';

  constructor(private http: HttpClient) {}

  getDriverDetail(userId: string) {
    return this.http.get<{ [key: string]: any }>(`${this.apiUrl}/driverDetails/${userId}.json`)
      .pipe(
        map(responseData => {
          const profilesArray = [];
          for (const key in responseData) {
            if (responseData.hasOwnProperty(key)) {
              profilesArray.push({ ...responseData[key], id: key, userId });
            }
          }
          return profilesArray.length > 0 ? profilesArray[0] : null;
        })
      );
  }
}
