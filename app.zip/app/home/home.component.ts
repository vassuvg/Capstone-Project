import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent   {

  showOverlay = true;
  selectedRole: string | null = null;
  showArrow = false; // Flag to control arrow visibility

  constructor() { }

  ngOnInit() { }

  selectRole(role: string) {
    this.selectedRole = role;
    this.showOverlay = false;
    this.showArrow = true;

    // Hide the arrow after 3 seconds
    setTimeout(() => {
      this.showArrow = false;
    }, 3000);
  }


}
