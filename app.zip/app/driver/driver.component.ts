import { Component, OnInit } from '@angular/core';
import { DriverService } from './driver.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-driver',
  templateUrl: './driver.component.html',
  styleUrls: ['./driver.component.scss'],
})
export class DriverComponent  implements OnInit {

 
  driverRoutes: any[] = [];
  routeNames: string[] = [];

  constructor(private driverService: DriverService, private router: Router) {}

  ngOnInit() {

   // this.routeNames = this.driverService.userName
    this.driverRoutes = this.driverService.availableRoutes;
   // this.routeNames = this.driverService.routeNames;

   
  }

  goToPassengerPage(): void {
    this.router.navigate(['/passenger']);
  }

  goToHomePage(): void {
    this.router.navigate(['/home']);
  }
  
  

}
