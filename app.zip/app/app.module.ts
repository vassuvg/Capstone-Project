import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy, RouterLink, RouterLinkActive } from '@angular/router';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { HomeModule } from './home/home.module';
import { DriverModule } from './driver/driver.module';
import { AccountModule } from './account/account.module';
import { DriverDetailModule } from './driver-detail/driver-detail.module';
import { DriverRideModule } from './driver-rideinfo/driver-rideinfo.module';
import { ViewrideDetailComponent } from './passenger/viewride-detail/viewride-detail.component';
import { ViewDriverRideInfoModule } from './viewdriver-rideinfo/viewdriver_rideinfo.module';
import { DriverInfoService } from './driver-rideinfo/driver-rideinfo.service';
import { DriverMyRidesService } from './driver-myrides/driver-myrides.service';
import { PwdResetModule } from './pwdreset/pwdreset.module';
import { AuthService } from './auth/auth.service';
import { FirebaseAuthentication } from '@ionic-native/firebase-authentication/ngx';

// Import environment for Firebase configuration
import { environment } from '../environments/environment';
import { PassengerHomeModule } from './passenger-home/passenger-home.module';
import { DriverHomeModule } from './driver-home/driver-home.module';




@NgModule({
  declarations: [AppComponent],
  imports: [BrowserModule, IonicModule.forRoot(), AppRoutingModule, IonicModule, CommonModule, RouterLink, RouterLinkActive, HttpClientModule, HomeModule, DriverModule, AccountModule, DriverDetailModule, DriverRideModule,  ViewDriverRideInfoModule, PwdResetModule, PassengerHomeModule, DriverHomeModule ],
  providers: [DriverInfoService, DriverMyRidesService ,{ provide: RouteReuseStrategy, useClass: IonicRouteStrategy }, AuthService, FirebaseAuthentication
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
