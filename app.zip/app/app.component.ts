import { Component } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { AuthService } from './auth/auth.service'; // Update the path as needed
import { filter } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  profileComplete: boolean ;
 
  /*constructor(private router: Router, private authService: AuthService) {
    this.authService.profileIsComplete.subscribe(isComplete => {
      this.profileComplete = isComplete;
    });
    this.authService.checkProfileCompletionStatus();// Check profile completion status on load 
  }*/

  constructor(private router: Router, private authService: AuthService) {
  // Check profile completion status on load
  }

  ngOnInit(): void {
    console.log("Init called")
      // this.appService.tabsVisibility$.subscribe(show => {
      //   this.profileComplete = show;
      // });
      // console.log("Profile comp",this.profileComplete)
      this.router.events.pipe(
        filter(event => event instanceof NavigationEnd)
      ).subscribe(() => {
        // Show tabs by default on navigation end, except for routes that need to hide them
        if (this.router.url == '/profile' || this.router.url == '/auth') {
         this.profileComplete=false
        }else{
          this.profileComplete=true
        }
      });
    }

  goToHomePage(): void {
    if (this.profileComplete) {
      this.router.navigate(['/home']);
    } else {
      alert('Please complete your profile first.');
    }}

  goToDriverPage(): void {
    if (this.profileComplete) {
      this.router.navigate(['/driver-home']);
    } else {
      alert('Please complete your profile first.');
    }
  }

  goToPassengerPage(): void {
    if (this.profileComplete) {
      this.router.navigate(['/passenger-home']);
    } else {
      alert('Please complete your profile first.');
    }
  }

  goToAccountPage(): void {
    if (this.profileComplete) {
      this.router.navigate(['/account']);
    } else {
      alert('Please complete your profile first.');
    }
  }
}
