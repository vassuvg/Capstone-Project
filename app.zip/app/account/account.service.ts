import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Account, DriverData } from "./account.model";
import { Observable } from "rxjs";
 
@Injectable({
    providedIn: 'root'
  })
  export class AccountService {
    private baseUrl = 'https://driveshare-c4036-default-rtdb.firebaseio.com/profiles';
    private baseUrl2= 'https://driveshare-c4036-default-rtdb.firebaseio.com/driverDetails'
 
    constructor(private http: HttpClient) {}
 
    // Update existing account (PATCH request)
    updateAccountFields(userID:string,TableID: string, updatedFields: Partial<Account>): Observable<void> {
      const url = `${this.baseUrl}/${userID}/${TableID}.json`;
      return this.http.patch<void>(url, updatedFields);
    }
    updateDriverDataFields(userID:string,TableID: string, updatedFields: Partial<DriverData>): Observable<void> {
      const url = `${this.baseUrl2}/${userID}/${TableID}.json`;
      return this.http.patch<void>(url, updatedFields);
    }
   
 
    // deleteAccount(userID: string): Observable<void> {
    //   const url = `${this.baseUrl2}/${userID}.json`;
    //   return this.http.delete<void>(url);
    // }
 
  }