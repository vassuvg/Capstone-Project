export interface Account {
    Tableid?: string;
    fullName?: string
    phoneNumber?: string;
    gender?: string;
    userId?: string;
    selectedImage?:string
 
  }
  export interface UpdateInfo{
    fullName?: string
    user_image?:string
    gender?: string;
 
 
  }
  export interface DriverData{
    car_image:string
    color:string
    driving_license:string
    license_plate:string
    model:string
    type:string
    year:string
   
  }