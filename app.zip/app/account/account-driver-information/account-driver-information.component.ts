import { DOCUMENT } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Platform } from '@ionic/angular';
import { AuthService } from 'src/app/auth/auth.service';
import { AccountService } from '../account.service';
import { Subscription, take } from 'rxjs';
import { DriverData } from '../account.model';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';
 
@Component({
  selector: 'app-account-driver-information',
  templateUrl: './account-driver-information.component.html',
  styleUrls: ['./account-driver-information.component.scss'],
})
export class AccountDriverInformationComponent implements OnInit {
  private authSub: Subscription;
  private previousAuthState = false;
  userId: string;
  emailId: string;
  tableID:string;
  Alldetails:DriverData
  DriverDetails:DriverData={
    car_image: '',
    color: '',
    driving_license: '',
    license_plate: '',
    model: '',
    type: '',
    year: ''
  };
  selectedImage:string='';
 
 HasProfileData:boolean;
  carModels: string[] = [
    'Honda',
    'Toyota',
    'Ford',
    'Chevrolet',
    'BMW',
    'Audi',
    'Mercedes-Benz',
    'Tesla',
    'Hyundai',
    'Nissan'
  ];
 
  constructor(private authService: AuthService, private router: Router, private accountService:AccountService  , private platform: Platform,  private http: HttpClient,@Inject(DOCUMENT) private document: Document) { }
 
  ngOnInit() {
    this.authSub = this.authService.userIsAuthenticated.subscribe(isAuth => {
      if (!isAuth && this.previousAuthState !== isAuth) {
        this.router.navigateByUrl('/auth');
      }
      this.previousAuthState = isAuth;
    });  
      this.authService.userId.pipe(take(1)).subscribe(userId => {
        this.userId = userId;
        console.log('Driver User ID:', this.userId);  // Log user ID for debugging
      //  this.initializeForm();
      });
      this.authService.emailId.pipe(
        take(1)
      ).subscribe(emailId => {
        this.emailId = emailId;
        console.log('Driver Email ID:', emailId);
      });
      this.GetFilteredAccount();
      // console.log(this.DriverDetails)
      // if (this.DriverDetails.driving_license=='' || this.DriverDetails.model=='' || this.DriverDetails.type==''){
      //   console.log("if called",this.DriverDetails)
      // }
  }
  async GetFilteredAccount(){
    this.http.get<DriverData>(`https://driveshare-c4036-default-rtdb.firebaseio.com/driverDetails/${this.userId}.json`)
     .subscribe(account => {
 
       if (account) {
        
         console.log("Driveraccounts:",account)
         this.Alldetails=account;
       //  console.log("All details",this.Alldetails);
        // console.log("Account",account)
         const dataArray = Object.keys(this.Alldetails).map(key => ({
          Tableid: key,
          ...this.Alldetails[key]

        }));
        console.log('Driver Data Array',dataArray);
        // export interface DriverData{
        //   carImage:string
        //   color:string
        //   drivingLicense:string
        //   licensePlate:string
        //   model:string
        //   carType:string
        //   userId:string
        //   year:string
     
        // }
       
         this.DriverDetails.car_image=String(dataArray[0].car_image)
        this.DriverDetails.color=dataArray[0].color
        this.DriverDetails.driving_license=dataArray[0].driving_license
        this.DriverDetails.license_plate=dataArray[0].license_plate
        this.DriverDetails.model=dataArray[0].model
        this.DriverDetails.type=dataArray[0].type
        this.DriverDetails.year=dataArray[0].year
        this.tableID=String(dataArray[0].Tableid)
       this.HasProfileData=true
 
         console.log("Alldetails driverdetails",this.DriverDetails);
        //  this.filteredAccounts = Object.keys(this.allAccount).filter((account: any) => {
        //   return account.userId === this.userId;
        //    // Example filter by gender
        // });
        // this.filteredAccounts = dataArray.find(x => x.userId === this.userId);
        // console.log("filteredAccounts",this.filteredAccounts);
        //  this.myAccount.Tableid = this.filteredAccounts.Tableid;
        //  this.myAccount.fullName=this.filteredAccounts.fullName;
        // this.myAccount.phoneNumber=this.filteredAccounts.phoneNumber
        // this.myAccount.gender=this.filteredAccounts.gender
        // this.myAccount.userId=this.filteredAccounts.userId // use the userId from ngoninit using auth service
        // this.myAccount.selectedImage=this.filteredAccounts.user_image
        // console.log("myAccount",this.myAccount)
       
       
        //try with model
         } else {
          this.HasProfileData=false
       }
     });
  }
 
  save(){
    console.log("DriverDetails",this.DriverDetails);
    console.log("ID",this.userId);
    console.log("TableID",this.tableID);
 
 
   this.accountService.updateDriverDataFields(this.userId,this.tableID,this.DriverDetails).subscribe(()=> {console.log("Driver Updated")})
  }
 
 
  async selectImage() {
    if (this.platform.is('capacitor') || this.platform.is('hybrid') || this.platform.is('desktop')|| this.platform.is('mobileweb')) {
      console.log(this.platform)
      try {
        const image = await Camera.getPhoto({
          quality: 90,
          allowEditing: false,
          resultType: CameraResultType.DataUrl,
          source: CameraSource.Prompt,
        });
       
//resize image is user defined function
        this.resizeImage(image.dataUrl, 500, 500).then(resizedImage => {
          this.selectedImage = resizedImage;
          console.log('SelectedImage',this.selectedImage)
          this.DriverDetails.car_image=this.selectedImage
         // this.profileForm.patchValue({ user_image: this.selectedImage });
        });
 
      } catch (error) {
        console.error('Error capturing image:', error);
      }
    } else {
      console.log('else called',this.platform)
      this.selectImageWeb();
     
    }
  }
//To click a picture using camera
  async takePicture() {
    if (this.platform.is('capacitor') || this.platform.is('hybrid') || this.platform.is('desktop') || this.platform.is('mobileweb')) {
      try {
        const image = await Camera.getPhoto({
          quality: 90,
          allowEditing: false,
          resultType: CameraResultType.DataUrl,
          source: CameraSource.Camera, // This will directly open the camera
        });
//resize image is a userr defined function
        this.resizeImage(image.dataUrl, 500, 500).then(resizedImage => {
          this.selectedImage = resizedImage;
          console.log('SelectedImage',this.selectedImage);
          this.DriverDetails.car_image=this.selectedImage
 
          // this.profileForm.patchValue({ user_image: this.selectedImage });
        });
 
      } catch (error) {
        console.error('Error capturing image:', error);
      }
    } else {
      console.error('Camera is not available on this platform');
    }
  }
 
 
  selectImageWeb() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (event: any) => {
      const file = event.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          const imageDataUrl = e.target.result as string;
          this.resizeImage(imageDataUrl, 500, 500).then(resizedImage => {
            this.selectedImage = resizedImage;
           // this.profileForm.patchValue({ user_image: this.selectedImage });
           console.log("SelectedImage",this.selectedImage)
          });
        };
        reader.readAsDataURL(file);
      }
    };
    input.click();
  }
 
  resizeImage(dataUrl: string, maxWidth: number, maxHeight: number): Promise<string> {
    return new Promise((resolve) => {
      const img = new Image();
      img.src = dataUrl;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;
 
        if (width > maxWidth) {
          height *= maxWidth / width;
          width = maxWidth;
        }
        if (height > maxHeight) {
          width *= maxHeight / height;
          height = maxHeight;
        }
 
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);
 
        resolve(canvas.toDataURL('image/jpeg', 0.8));
      };
    });
  }
 
 
 
 
 
  OnDestroy(): void {
    if (this.authSub) {
      this.authSub.unsubscribe();
    }
  }
 
 
}