import { NgModule,CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { AccountComponent } from './account.component';
import { FormsModule } from '@angular/forms';
import { AccountDriverInformationComponent } from './account-driver-information/account-driver-information.component';
import { AccountMyInformationComponent } from './account-my-information/account-my-information.component';
 
const routes: Routes = [
  {
    path: '',
    component:AccountComponent
  }
];
 
@NgModule({
  declarations: [
    AccountComponent, AccountDriverInformationComponent, AccountMyInformationComponent
  ],
  imports: [
    CommonModule,
    IonicModule,
    FormsModule,
    RouterModule.forChild(routes),
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
 
 
})
export class AccountModule { }