import { Component, ElementRef, Inject, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { AuthService } from '../auth/auth.service';
import { Router } from '@angular/router';
import { Subscription, take } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Account, UpdateInfo } from './account.model';
import { DOCUMENT } from '@angular/common';
import { AccountService } from './account.service';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';
import { Platform } from '@ionic/angular';
import 'firebase/auth';
 
 
 
@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.scss'],
})
export class AccountComponent implements OnInit, OnDestroy {
  public Name:string;
  public Gender:string;
  inputName: string = '';
 
  private authSub: Subscription;
  private previousAuthState = false;
  userId: string='';
  emailId:string='';
  selectedImage:string='';
  private allAccount: any='';
  private filteredAccounts;
  myAccount: Account = {
    Tableid:null,
    fullName: null,
    phoneNumber: '',
    gender: '',
    userId:'',
    selectedImage:''
  };
  UpdateAccountInfo: UpdateInfo = {
    fullName: '',
    gender: '',
    user_image:''
  };
 
 
 
 
  constructor(private authService: AuthService, private router: Router, private AccountService:AccountService  , private platform: Platform,  private http: HttpClient,@Inject(DOCUMENT) private document: Document
  ) { }
 
  ngOnInit() {
    this.authSub = this.authService.userIsAuthenticated.subscribe(isAuth => {
      if (!isAuth && this.previousAuthState !== isAuth) {
        this.router.navigateByUrl('/auth');
      }
      this.previousAuthState = isAuth;
    });
 
      this.authService.userId.pipe(take(1)).subscribe(userId => {
        this.userId = userId;
        console.log('User ID:', this.userId);  // Log user ID for debugging
      //  this.initializeForm();
      });
 
      this.authService.emailId.pipe(
        take(1)
      ).subscribe(emailId => {
        this.emailId = emailId;
        //console.log('Email ID:', emailId);
      });
      //const data=`https://driveshare-c4036-default-rtdb.firebaseio.com/profiles.json`
     // console.log('profiles',data);
     this.GetFilteredAccount();
    }
  async GetFilteredAccount(){
    this.http.get<Account>(`https://driveshare-c4036-default-rtdb.firebaseio.com/profiles/${this.userId}.json`)
     .subscribe(account => {
 
       if (account) {
       //  console.log("accounts:",account)
         this.allAccount=account;
         
         const dataArray = Object.keys(this.allAccount).map(key => ({
          Tableid: key,
          ...this.allAccount[key]
        }));
       
       // console.log('dayaarray',dataArray);
 
       //  console.log("Allaccouts",this.allAccount);
        //  this.filteredAccounts = Object.keys(this.allAccount).filter((account: any) => {
        //   return account.userId === this.userId;
        //    // Example filter by gender
        // });
        this.filteredAccounts = dataArray.find(x => x.userId === this.userId);
       // console.log("filteredAccounts",this.filteredAccounts);
         this.myAccount.Tableid = this.filteredAccounts.Tableid;
         this.myAccount.fullName=this.filteredAccounts.fullName;
        this.myAccount.phoneNumber=this.filteredAccounts.phoneNumber
        this.myAccount.gender=this.filteredAccounts.gender
        this.myAccount.userId=this.filteredAccounts.userId // use the userId from ngoninit using auth service
        this.myAccount.selectedImage=this.filteredAccounts.user_image
      //  console.log("myAccount",this.myAccount)
       
       
        //try with model
         } else {
       }
     });
  }
 
 
 
  logout() {
    this.authService.logout();
// console.log(this.myAccount)
// this.document.location.reload();
 
  }
 
  ngOnDestroy(): void {
    if (this.authSub) {
      this.authSub.unsubscribe();
    }
  }
 
}