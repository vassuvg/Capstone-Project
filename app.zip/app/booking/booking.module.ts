import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { RouterModule } from '@angular/router';
import { BookingComponent } from './booking.component';
import { StartRideComponent } from './start-ride/start-ride.component';


@NgModule({
  declarations: [BookingComponent, StartRideComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    IonicModule,
    RouterModule.forChild([
      {
        path: '',
        component:BookingComponent
      }
    ])
  ],
})
export class BookingModule {}