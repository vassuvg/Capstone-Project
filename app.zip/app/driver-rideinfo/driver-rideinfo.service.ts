import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, map } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DriverInfoService {

  private baseUrl = 'https://driveshare-c4036-default-rtdb.firebaseio.com';

private driverStateSubject = new BehaviorSubject<any>(null);
driverState$ = this.driverStateSubject.asObservable();
  private pickupQuery = new BehaviorSubject<string>(null);
  private dropoffQuery = new BehaviorSubject<string>(null);



  constructor (private http : HttpClient){}
  setPickupQuery(pickup: string) {
    if (pickup) {
      this.pickupQuery.next(pickup);
    } else {
      this.pickupQuery.next(null);
    }
  }

  getPickupQuery() {
    return this.pickupQuery.asObservable();
  }

  setDropoffQuery(dropoff: string) {
    if (dropoff) {
      this.dropoffQuery.next(dropoff);
    } else {
      this.dropoffQuery.next(null);
    }
  }

  getDropoffQuery() {
    return this.dropoffQuery.asObservable();
  }

  getCurrentPickupQuery() {
    return this.pickupQuery.getValue();
  }

  getCurrentDropoffQuery() {
    return this.dropoffQuery.getValue();
  }
  
 // getPickupLocation(): Observable<any> {
   // return this.http.get(`https://driveshare-c4036-default-rtdb.firebaseio.com/driverpickupLocations.json`);
  //}

 /* getPickupLocation(userId: string, driverId: string): Observable<string> {     
    return this.http.get<string>(`https://driveshare-c4036-default-rtdb.firebaseio.com/driverpickupLocations/${userId}/${driverId}/location.json`); 
    
  }
  

  getDropoffLocation(userId: string, driverId: string): Observable<string> {
    return this.http.get<string>(`https://driveshare-c4036-default-rtdb.firebaseio.com/driverdropoffLocations/${userId}/${driverId}/location.json`);
  }
*/

 getPickupLocation(): Observable<string> {     
   // return this.http.get<string>(`https://driveshare-c4036-default-rtdb.firebaseio.com/driverpickupLocations.json`); 
   return this.http.get<string>(`https://driveshare-c4036-default-rtdb.firebaseio.com/driverRideData.json`);
    
  }
  

  getDropoffLocation(): Observable<string> {
    return this.http.get<string>(`https://driveshare-c4036-default-rtdb.firebaseio.com/driverRideData.json`);
  }


  getDriverData(userId: string): Observable<any> {
    const url = `${this.baseUrl}/driverRideData/${userId}.json`;
    return this.http.get<any>(url).pipe(
      map(data => {
        const keys = Object.keys(data);
        if (keys.length > 0) {
          return { tableId: keys[0], ...data[keys[0]] };
        }
        return null;
      })
    );
  }
  getDriverRideId(){
    return this.http.get<string>(`https://driveshare-c4036-default-rtdb.firebaseio.com/driverRideData.json`);
  }
  // getDriverRideId(userId: string): Observable<any> {
  //   return this.http.get<any>(`https://driveshare-c4036-default-rtdb.firebaseio.com/driverRideData/${userId}.json`)
  //     .pipe(
  //       map(data => {
  //         const keys = Object.keys(data);
  //         if (keys.length > 0) {
  //           return { tableId: keys[0], ...data[keys[0]] };
  //         }
  //         return null;
  //       })
  //     ); // Extract nested keys
      
  // }
  

   // Method to set the driver state
   setDriverState(state: any): void {
    this.driverStateSubject.next(state);
  }

  // Method to get the current driver state
  getDriverState() {
    return this.driverState$;
  }



}
