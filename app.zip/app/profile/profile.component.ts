import { Component, OnInit, OnDestroy } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { AuthService } from '../auth/auth.service';
import { Profile } from './profile.model';
import { Subscription } from 'rxjs';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';
import { Platform, ActionSheetController, AlertController } from '@ionic/angular';
import { FirebaseAuthentication } from '@ionic-native/firebase-authentication/ngx';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss'],
})
export class ProfilePage implements OnInit, OnDestroy {
  profileForm: FormGroup;
  profile: Profile = {
    user_image: '',
    fullName: '',
    phoneNumber: '',
    gender: ''
  };
  userId: string;
  private authSub: Subscription;
  private userIdSub: Subscription;
  selectedImage: string | undefined;
  verificationId: string;
  verificationInProgress: boolean = false;
  codeSent: boolean = false;
  isPhoneVerified: boolean = false; // New flag to check if phone is verified

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private http: HttpClient,
    private authService: AuthService,
    private platform: Platform,
    public actionSheetController: ActionSheetController,
    private alertController: AlertController,
    private firebaseAuthentication: FirebaseAuthentication
  ) {}

  ngOnInit(): void {
    this.authSub = this.authService.userIsAuthenticated.subscribe(isAuth => {
      if (!isAuth) {
        this.resetForm();
      }
    });

    this.userIdSub = this.authService.userId.subscribe(userId => {
      this.userId = userId;
      if (this.userId) {
        this.initializeForm();
        this.loadUserProfile(this.userId);
      }
    });
  }

  ngOnDestroy(): void {
    if (this.authSub) {
      this.authSub.unsubscribe();
    }
    if (this.userIdSub) {
      this.userIdSub.unsubscribe();
    }
  }

  initializeForm() {
    this.profileForm = this.fb.group({
      user_image: [null],
      fullName: ['', Validators.required],
      phoneNumber: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      gender: ['', Validators.required]
    });
  }

  loadUserProfile(userId: string) {
    this.http.get<Profile>(`https://driveshare-c4036-default-rtdb.firebaseio.com/profiles/${this.userId}.json`)
      .subscribe(profile => {
        if (profile) {
          this.profileForm.patchValue({
            user_image: profile.user_image,
            fullName: profile.fullName,
            phoneNumber: profile.phoneNumber,
            gender: profile.gender
          });
          this.selectedImage = profile.user_image;
        } else {
          this.resetForm();
        }
      });
  }

  get f() { return this.profileForm.controls as { [key: string]: AbstractControl }; }

  onSubmit() {
    if (this.profileForm.invalid || !this.isPhoneVerified) {
      this.presentAlert('Error', 'Please complete the form and verify your phone number.');
      return;
    }

    this.profile.user_image = this.profileForm.value.user_image;
    this.profile.fullName = this.profileForm.value.fullName;
    this.profile.phoneNumber = this.profileForm.value.phoneNumber;
    this.profile.gender = this.profileForm.value.gender;

    if (this.userId) {
      this.profile.userId = this.userId;

      this.http.post(`https://driveshare-c4036-default-rtdb.firebaseio.com/profiles/${this.userId}.json`, this.profile)
        .subscribe(
          (response: any) => {
            console.log('POST request successful:', response);
            this.router.navigate(['/home']);
          },
          (error) => {
            console.error('Error making POST request:', error);
          }
        );

      this.profileForm.reset();
    } else {
      console.error('User ID is not available');
    }
  }

  async selectImage() {
    if (this.platform.is('capacitor') || this.platform.is('hybrid') || this.platform.is('desktop')) {
      try {
        const image = await Camera.getPhoto({
          quality: 90,
          allowEditing: false,
          resultType: CameraResultType.DataUrl,
          source: CameraSource.Prompt,
        });

        this.resizeImage(image.dataUrl, 500, 500).then(resizedImage => {
          this.selectedImage = resizedImage;
          this.profileForm.patchValue({ user_image: this.selectedImage });
        });

      } catch (error) {
        console.error('Error capturing image:', error);
      }
    } else {
      this.selectImageWeb();
    }
  }

  async takePicture() {
    if (this.platform.is('capacitor') || this.platform.is('hybrid') || this.platform.is('desktop') || this.platform.is('mobileweb')) {
      try {
        const image = await Camera.getPhoto({
          quality: 90,
          allowEditing: false,
          resultType: CameraResultType.DataUrl,
          source: CameraSource.Camera,
        });

        this.resizeImage(image.dataUrl, 500, 500).then(resizedImage => {
          this.selectedImage = resizedImage;
          this.profileForm.patchValue({ user_image: this.selectedImage });
        });

      } catch (error) {
        console.error('Error capturing image:', error);
      }
    } else {
      console.error('Camera is not available on this platform');
    }
  }

  selectImageWeb() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (event: any) => {
      const file = event.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          const imageDataUrl = e.target.result as string;
          this.resizeImage(imageDataUrl, 500, 500).then(resizedImage => {
            this.selectedImage = resizedImage;
            this.profileForm.patchValue({ user_image: this.selectedImage });
          });
        };
        reader.readAsDataURL(file);
      }
    };
    input.click();
  }

  resizeImage(dataUrl: string, maxWidth: number, maxHeight: number): Promise<string> {
    return new Promise((resolve) => {
      const img = new Image();
      img.src = dataUrl;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        if (width > maxWidth) {
          height *= maxWidth / width;
          width = maxWidth;
        }
        if (height > maxHeight) {
          width *= maxHeight / height;
          height = maxHeight;
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);

        resolve(canvas.toDataURL('image/jpeg', 0.8));
      };
    });
  }

  async verifyPhoneNumber() {
    const phoneNumber = `+1${this.f['phoneNumber'].value}`;

    try {
      const result = await this.firebaseAuthentication.verifyPhoneNumber(phoneNumber, 60);
      this.verificationId = result;
      this.presentCodePrompt();
      this.codeSent = true;
    } catch (error) {
      console.error('Error sending verification code:', error);
      this.presentAlert('Error', 'Failed to send verification code. Please try again.');
    }
  }

  async verifyCode(code: string) {
    try {
      const result = await this.firebaseAuthentication.signInWithVerificationId(this.verificationId, code);
      console.log('Phone number verified successfully:', result);
      this.presentAlert('Success', 'Phone number verified successfully.');
      this.codeSent = false; // Reset codeSent after successful verification
      this.isPhoneVerified = true; // Mark phone as verified
    } catch (error) {
      console.error('Error verifying code:', error);
      this.presentAlert('Error', 'Invalid verification code. Please try again.');
      this.isPhoneVerified = false; // Mark phone as not verified
    }
  }

  async presentAlert(header: string, message: string) {
    const alert = await this.alertController.create({
      header: header,
      message: message,
      buttons: ['OK']
    });

    await alert.present();
  }

  async presentCodePrompt() {
    const alert = await this.alertController.create({
      header: 'Enter Verification Code',
      inputs: [
        {
          name: 'verificationCode',
          type: 'text',
          placeholder: 'Verification Code'
        }
      ],
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            console.log('Code input cancelled');
          }
        },
        {
          text: 'Verify',
          handler: (data) => {
            if (data.verificationCode) {
              this.verifyCode(data.verificationCode);
            }
          }
        }
      ]
    });

    await alert.present();
  }

  resetForm() {
    this.profileForm.reset();
    this.selectedImage = undefined;
    this.verificationId = '';
    this.verificationInProgress = false;
    this.codeSent = false;
    this.isPhoneVerified = false;
  }
}
