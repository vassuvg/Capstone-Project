export interface Profile {
    user_image : string;
    fullName: string
    phoneNumber: string;
    gender: string;
    userId?: string;
  }